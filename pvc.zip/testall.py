#!/usr/bin/env python3
# testall.py  Updated: 2025.04.14.13.00
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Execute all dv.py test scripts
# *LXA-ODF*PersonalVersionControl.odt*^3DvGetTest* LinkXall link
# ----------------------------------------------------------------------
import os, stat, filecmp, shutil, sys
cwd = os.getcwd()
tests = ('testput', 'testsrc', 'testref', 'testcmp', 'testget', 'testdel', 'testdels')
errors = []
errtot = 0
for pgm in tests :
    print('\n<<<<<<<<<<<<<<< %s >>>>>>>>>>>>>>>>'%pgm)
    err = os.system(os.path.normpath('%s/%s.py'%(cwd,pgm)))%255
# Linux may screw up non-0 exit codes, e.g. 1->256, 3->768, 7->1792. mod 255
# restores the actual value without screwing up Windows correct return. 
    errtot += err
    errors.append(err)

print('\n%d errors'%errtot)
if errtot > 0 :
    for t in zip(tests,errors) :
        print(t, end = '  ')
    print("")

exit(errtot)
