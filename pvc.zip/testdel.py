#!/usr/bin/env python3
# testdel.py Updated: 2025.04.15.12.58
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Test dv.py del operation without shift. testdels.py tests del with shift.
# *LXA-ODF*PersonalVersionControl.odt*^3DvDeleteTest* LinkXall link
#
# For each general test, testput.py is invoked once (by prepx) to provide a 
# consistent initial condition. It is not invoked at the end, leaving the 
# repository in a condition that causes other tests to report errors. 
# ----------------------------------------------------------------------
import os, filecmp, sys, json
errors = 0

#rmtree ----------------------------------------------------------
# Remove a directory and all of its files and descendents.
def rmtree(dpath) :
    if os.path.exists(dpath) :
        for f in os.listdir(dpath) :
            fp = dpath + '/' + f
            if os.path.isdir(fp) :
                rmtree(fp)
            else :
                os.remove(fp) 
        os.rmdir(dpath)

#writeFile ------------------------------------------------
def writeFile(fname, content) :
    with open(fname, 'wt') as f :
        f.write(content)

#rptmis ------------------------------------------------------
def rptmis(f1, f2) :
    if not os.path.exists(f1) :
        print('%s missing'%f1)
        return 1
    elif not os.path.exists(f2) :
        print('%s missing'%f2)
        return 1
    elif not filecmp.cmp(f1, f2) :
        print('%s does not match %s'%(f1,f2))
        return 1
    return 0

#dirf --------------------------------------------------------------
# Test whether a directory contains exactly the files in a list.
def dirf(dir, flist) :
    global errors
    dirlist = os.listdir(dir)
    dirlist.sort()
    if dirlist == flist :
        cond = 'correct'
    else :
        cond = 'wrong'
        errors += 1
    print('%s: %s is %s'%(dir,dirlist,cond))

#verdic -------------------------------------------------------------
# Make a dictionary from a version's vdict file.
# Return dictionary, which is empty if the file does not exist.
# Argument vdir string is abs path to the version directory.
# ............................................................
def verdic(vdir) :
    dic = {}
    dfile = vdir + '/vdict'
    if os.path.exists(dfile) :
        with open(dfile, 'rt') as f :
            dic = json.load(f)
    return(dic)

#testver ---------------------------------------------
# Test a version directory for files and vdict content. Print a list of the 
# files and the dictionary. If they match the expected patterns, print that 
# they are correct. If not then print that they are wrong and increment global 
# errors.
# Arguments:
#- vdir is the directory path
#- vlist is a list of the expected file names
#- vdic is the expected dictionary.
# ................................................................
def testver(vdir, vlist, vdic) :
    global errors
    dlist = os.listdir(vdir)
    dlist.sort()
    if dlist != vlist :
        match = 'wrong'
        errors += 1
    else :
        match = 'correct'
    print('\n%s: %s is %s'%(vdir, dlist, match))
    with open(vdir + '/vdict', 'rt') as f : dic = f.read()
    print(dic, end = ' is ')
    if dic != vdic :
        errors += 1
        print('wrong')
    else :
        print('correct')

#testrm -----------------------------------------------------------
# Test for whether dv-del has removed or not deleted version directories as
# specified by actual or simulated user. If multiple directories, the first
# one in the list that is incorrectly removed or not removed is reported, the
# rest are ignored and only one error is counted.
# Return 0 if no error else 1.
# Arguments:
#- vdirs is a list of the version directories to be tested.
#- yn is 0 if they are expected missing or 1 if not.
# .................................................................
def testrm(vdirs,yn) :
    global errors
    for vd in vdirs :
        if ((1 if os.path.exists('bak/%s'%vd) else 0) ^ yn) != 0 :
            print('%s was incorrectly %s removed'%(vd,'not' if yn == 0 else ""))
            errors += 1
            return 1
    return 0

#execmd ----------------------------------------------------
# Display and execute the given command.
def execmd(cmd) :
    print('\n%s'%cmd)
    os.system(cmd if oswin else './%s'%cmd)

#prepx ------------------------------------------------------------
# Called before each invocation of dv-del to prepare a consistent group 
# regardless of preceding tests.
def prepx() :
    print('\n--- Make fresh x0-x6 group ---', end="")
    execmd('testput.py quiet')

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'
# os.system('testput.py' if oswin else './testput.py') 

#DeleteX0 --------------------------------------------------------
prepx()
print('========== Test delete version x0 ============ ', end = "")
execmd('dv.py x0 -del x0 @ Y N') # delete x0 but don't remove bak/x0
testrm(['x0'],1)

testver('bak/x1', ['1.x', '2.x', '3.x', '4.x', '5.x', '6.x', 'vdict'], 
'{"1.x": [3646614595, "x1"], "2.x": [4067934080, "x1"], "3.x": [3949760193, "x1"], "4.x": [2754418694, "x1"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"]}')

testver('bak/x2', ['1.x', '7.x', 'vdict'], 
'{"2.x": [4067934080, "x1"], "3.x": [3949760193, "x1"], "4.x": [2754418694, "x1"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "1.x": [1475035452, "x2"]}')

testver('bak/x3', ['8.x', 'vdict'], 
'{"2.x": [4067934080, "x1"], "3.x": [3949760193, "x1"], "4.x": [2754418694, "x1"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "1.x": [1475035452, "x2"], "8.x": [144201482, "x3"]}')

testver('bak/x4', ['1.x', '9.x', 'vdict'], 
'{"2.x": [4067934080, "x1"], "3.x": [3949760193, "x1"], "4.x": [2754418694, "x1"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "1.x": [1567976502, "x4"]}')

testver('bak/x5', ['10.x', 'vdict'], 
'{"2.x": [4067934080, "x1"], "3.x": [3949760193, "x1"], "4.x": [2754418694, "x1"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "1.x": [1567976502, "x4"], "10.x": [1534105928, "x5"]}')

testver('bak/x6', ['1.x', '11.x', 'vdict'], 
'{"2.x": [4067934080, "x1"], "3.x": [3949760193, "x1"], "4.x": [2754418694, "x1"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "10.x": [1534105928, "x5"], "11.x": [1114351625, "x6"], "1.x": [1417620892, "x6"]}')
print('--------------------------')

#DeleteX2 -----------------------------------------------------------
prepx()
print('================ Test delete version x2 ==============', end = "")
execmd('dv.py x2 -del @ Y Y N') # delete version and directory but don't shift
testrm(['x2'],0)

testver('bak/x0', ['1.x', '2.x', '3.x', '4.x', 'vdict'], 
'{"1.x": [3646614595, "x0"], "2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"]}')

testver('bak/x1', ['5.x', '6.x', 'vdict'], 
'{"1.x": [3646614595, "x0"], "2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"]}')

testver('bak/x3', ['1.x', '7.x', '8.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x3"], "1.x": [1475035452, "x3"], "8.x": [144201482, "x3"]}')

testver('bak/x4', ['1.x', '9.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x3"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "1.x": [1567976502, "x4"]}')

testver('bak/x5', ['10.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x3"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "1.x": [1567976502, "x4"], "10.x": [1534105928, "x5"]}')

testver('bak/x6', ['1.x', '11.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x3"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "10.x": [1534105928, "x5"], "11.x": [1114351625, "x6"], "1.x": [1417620892, "x6"]}')
print('--------------------------------')

#DeleteX0-X3 ---------------------------------------------------------
prepx()
print('=============== Test delete versions x0 through x3 =============', end = "")
execmd('dv.py x0 -del x3 @ Y Y N') # delete versions and directories but don't shift.
testrm(['x0','x1','x2','x3'],0)

testver('bak/x4', ['1.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x', 'vdict'], 
'{"2.x": [4067934080, "x4"], "3.x": [3949760193, "x4"], "4.x": [2754418694, "x4"], "5.x": [3174443335, "x4"], "6.x": [2518383236, "x4"], "7.x": [2399161285, "x4"], "8.x": [144201482, "x4"], "9.x": [293824075, "x4"], "1.x": [1567976502, "x4"]}')

testver('bak/x5', ['10.x', 'vdict'], 
'{"2.x": [4067934080, "x4"], "3.x": [3949760193, "x4"], "4.x": [2754418694, "x4"], "5.x": [3174443335, "x4"], "6.x": [2518383236, "x4"], "7.x": [2399161285, "x4"], "8.x": [144201482, "x4"], "9.x": [293824075, "x4"], "1.x": [1567976502, "x4"], "10.x": [1534105928, "x5"]}')

testver('bak/x6', ['1.x', '11.x', 'vdict'], 
'{"2.x": [4067934080, "x4"], "3.x": [3949760193, "x4"], "4.x": [2754418694, "x4"], "5.x": [3174443335, "x4"], "6.x": [2518383236, "x4"], "7.x": [2399161285, "x4"], "8.x": [144201482, "x4"], "9.x": [293824075, "x4"], "10.x": [1534105928, "x5"], "11.x": [1114351625, "x6"], "1.x": [1417620892, "x6"]}')
print('--------------------------')

#SaveOrphans ------------------------------------------------------------
print('========= Test saving unreferenced files in deleted versions =========')
rmtree('dead') # dv-del will make new without asking.
prepx()
dic = verdic('bak/x7') # Capture this for verifying moved sources.
execmd('dv.py x0 -del x6 dead @ Y N') # Y delete versions. N remove directories.
testver('bak/x7', ['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', 
'7.x', '8.x', '9.x', 'vdict'], 
'{"2.x": [4067934080, "x7"], "3.x": [3949760193, "x7"], "4.x": [2754418694, "x7"], "5.x": [3174443335, "x7"], "6.x": [2518383236, "x7"], "7.x": [2399161285, "x7"], "8.x": [144201482, "x7"], "9.x": [293824075, "x7"], "10.x": [1534105928, "x7"], "11.x": [1114351625, "x7"], "1.x": [1417620892, "x7"]}')

err = 0
# writeFile('bak/x7/1.x', 'Bad') # Test the tester.
# os.remove('bak/x7/2.x') # Test the tester.
for f,v in dic.items() :
    err += rptmis('bak/x7/%s'%f, 'bak/%s/%s'%(v[1],f)) 
if err > 0 : errors += 1   

# Verify 'x0-1.x', 'x2-1.x', 'x4-1.x' in dead   
if rptmis('dead/x0-1.x', 'bak/x0/1.x') + rptmis('dead/x2-1.x', 'bak/x2/1.x') + \
   rptmis('dead/x4-1.x', 'bak/x4/1.x') > 0 : errors += 1

prepx()
execmd('dv.py x0 -del x7 dead @ Y N N Y') # del vers Y, rem dirs N, clear dead Y
dlist = ['x0-1.x', 'x0-2.x', 'x0-3.x', 'x0-4.x', 'x1-5.x', 'x1-6.x', 'x2-1.x', 'x2-7.x', 'x3-8.x', 'x4-1.x', 'x4-9.x', 'x5-10.x', 'x6-1.x', 'x6-11.x']
err = 0
for f in dlist :
    err += rptmis('dead/%s'%f, 'bak/%s'%f.replace('-','/'))
if err > 0 : errors += 1
#dirf('dead',['x0-1.x', 'x0-2.x', 'x0-3.x', 'x0-4.x', 'x1-5.x', 'x1-6.x', 
#'x2-1.x', 'x2-7.x', 'x3-8.x', 'x4-1.x', 'x4-9.x', 'x5-10.x', 'x6-1.x', 'x6-11.x'])

prepx()
writeFile('bak/x0/noref', 'alone')
execmd('dv.py x0 -del x0 dead @ Y N Y') # del vers Y, rem dirs N, clear dead Y
dirf('dead', ['x0-noref'])

# ========================================================================    
print('\n%d errors'%errors)
exit(errors)
