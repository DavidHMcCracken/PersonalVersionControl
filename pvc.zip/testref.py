#!/usr/bin/env python3
# testref.py  Updated: 2025.03.29.09.10
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Test dv.py ref operation. Execute after testput. 
# *LXA-ODF*PersonalVersionControl.odt*^3DvCmpTest* (LinkXall link)
#
# testput must have previously executed to set up the repository. It need not 
# execute again unless testdel executes.
# ----------------------------------------------------------------------
import os, sys 
errors = 0

#writeFile ------------------------------------------------
def writeFile(fname, content) :
    with open(fname, 'wt') as f :
        f.write(content)

#testcmd -------------------------------------------------------------
# Execute the given dv command with console output redirected into a file,
# which is compared to the given list of expected lines. The command and actual
# list are displayed with the comment 'correctly' if the lists match or
# 'incorrectly if they don't (which also increments errors)
# Arguments:
#- cmd is the dv command string.
#- expect is a list of the expected output lines.
# ...................................................................
def testcmd(arg,expect) :
    global errors
    os.system('%s %s > cmpres'%('dv.py' if oswin else './dv.py', arg))
    with open('cmpres','rt') as f : res = f.readlines()
    if res == expect :
        result = 'correctly'
    else :
        result = 'incorrectly'
        errors += 1
    print('\n%s %s produces'%('dv.py %s'%arg, result))
    for line in res : print(line, end = "")

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'
# os.system('testput.py' if oswin else './testput.py') 

testcmd('x0 -ref',
['x0/1.x < x1\n',
'x0/2.x < x1,x2,x3,x4,x5,x6,x7\n',
'x0/3.x < x1,x2,x3,x4,x5,x6,x7\n',
'x0/4.x < x1,x2,x3,x4,x5,x6,x7\n'])

testcmd('x3 -ref x5',
['x3/8.x < x4,x5,x6,x7\n',
'x4/9.x < x5,x6,x7\n',
'x4/1.x < x5\n',
'x5/10.x < x6,x7\n'])

testcmd('x0 -ref x7',
['x0/1.x < x1\n',
'x0/2.x < x1,x2,x3,x4,x5,x6,x7\n',
'x0/3.x < x1,x2,x3,x4,x5,x6,x7\n',
'x0/4.x < x1,x2,x3,x4,x5,x6,x7\n',
'x1/5.x < x2,x3,x4,x5,x6,x7\n',
'x1/6.x < x2,x3,x4,x5,x6,x7\n',
'x2/7.x < x3,x4,x5,x6,x7\n',
'x2/1.x < x3\n',
'x3/8.x < x4,x5,x6,x7\n',
'x4/9.x < x5,x6,x7\n',
'x4/1.x < x5\n',
'x5/10.x < x6,x7\n',
'x6/11.x < x7\n',
'x6/1.x < x7\n'])

unrefs = ['bak/x%d/z%d'%(idx,10-idx) for idx in range(0,7)]
for vd in unrefs : writeFile(vd, 'hi')
testcmd('x0 -ref x7',
['x0/1.x < x1\n',
'x0/2.x < x1,x2,x3,x4,x5,x6,x7\n',
'x0/3.x < x1,x2,x3,x4,x5,x6,x7\n',
'x0/4.x < x1,x2,x3,x4,x5,x6,x7\n',
'x1/5.x < x2,x3,x4,x5,x6,x7\n',
'x1/6.x < x2,x3,x4,x5,x6,x7\n',
'x2/7.x < x3,x4,x5,x6,x7\n',
'x2/1.x < x3\n',
'x3/8.x < x4,x5,x6,x7\n',
'x4/9.x < x5,x6,x7\n',
'x4/1.x < x5\n',
'x5/10.x < x6,x7\n',
'x6/11.x < x7\n',
'x6/1.x < x7\n',
'Unreferenced: x0/z10, x1/z9, x2/z8, x3/z7, x4/z6, x5/z5, x6/z4\n'])

for vd in unrefs : os.remove(vd)

print('\n%d errors'%errors)
exit(errors)
