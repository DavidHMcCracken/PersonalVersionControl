#!/usr/bin/env python3
# This shebang is only for Linux. Without it many distros default to Python 2, 
# which cannot execute this script. Also for Linux, this file uses Unix line 
# endings. This is only for the shebang line. Python doesn't care.
#
# pvczip.py Updated: 2025.08.22.13.24
# Make pvc.zip
# *LXA-ODF*|LXADOC|LxaDesign.odt*^2InstallerWorkspace*
# --------------------------------------------------------------
import zipfile, os, stat
ctype = zipfile.ZIP_DEFLATED

#listext ---------------------------------------------------------------
# Return a list of files with a specified extension. 
# Arguments:
#- d is the directory in which to look for these files.
#- ext is the extension, most reliably including "." prefix.
# .......................................................................
def listext(d, ext) :
    return [f for f in os.listdir(d) if f[-len(ext):] == ext]

zf = zipfile.ZipFile('pvc.zip',mode='w')
for f in listext(os.getcwd(), '.py') :
    zf.write( f, compress_type = ctype )
zf.write( 'dvcfg', compress_type = ctype )
zf.write( 'bvcfg', compress_type = ctype )
zf.write( 'PersonalVersionControl.odt', compress_type = ctype )
zf.close()
