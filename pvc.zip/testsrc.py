#!/usr/bin/env python3
# testsrc.py  Updated: 2025.03.29.09.10
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Test dv.py src operation. Execute after testput. 
# *LXA-ODF*PersonalVersionControl.odt*^3DvCmpTest* (LinkXall link)
#
# testput must have previously executed to set up the repository. It need
# not execute again unless testdel executes.
# ----------------------------------------------------------------------
import os, sys 
errors = 0

#testcmd -------------------------------------------------------------
# Execute the given dv command with console output redirected into a file,
# which is compared to the given list of expected lines. The command and actual
# list are displayed with the comment 'correctly' if the lists match or
# 'incorrectly if they don't (which also increments errors)
# Arguments:
#- cmd is the dv command string.
#- expect is a list of the expected output lines.
# ...................................................................
def testcmd(arg,expect) :
    global errors
    os.system('%s %s > cmpres'%('dv.py' if oswin else './dv.py', arg))
    with open('cmpres','rt') as f : res = f.readlines()
    if res == expect :
        result = 'correctly'
    else :
        result = 'incorrectly'
        errors += 1
    print('\n%s %s produces'%('dv.py %s'%arg, result))
    for line in res : print(line, end = "")

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'
# os.system('testput.py' if oswin else './testput.py') 

testcmd('x0 -src',['x0 sources are x0/1.x, x0/2.x, x0/3.x, x0/4.x\n'])

testcmd('x1 -src',
['x1 sources are x0/1.x, x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x\n'])

testcmd('x2 -src',
['x2 sources are x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x2/1.x\n'])

testcmd('x3 -src',
['x3 sources are x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x2/1.x, x3/8.x\n'])

testcmd('x4 -src',
['x4 sources are x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x, x4/1.x\n'])

testcmd('x5 -src',
['x5 sources are x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x, x4/1.x, x5/10.x\n'])

testcmd('x6 -src', 
['x6 sources are x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x, x5/10.x, x6/11.x, x6/1.x\n'])

testcmd('x7 -src',
['x7 sources are x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x, x5/10.x, x6/11.x, x6/1.x\n'])

print('\n%d errors'%errors)
exit(errors)




