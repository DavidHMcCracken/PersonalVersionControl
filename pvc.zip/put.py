#!/usr/bin/env python3
# put.py  Updated: 2025.08.22.12.01
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Put all files in the PVC project.
# *LXA-ODF*PersonalVersionControl.odt*^1Use* LinkXall link.
# ----------------------------------------------------------------------
import os, stat, filecmp, shutil, sys
dvp = os.path.normpath('%s/dv.py'%os.getcwd())
os.system('%s dvc+ .py dvcfg bvcfg'%dvp)
os.system('%s doc+ .odt'%dvp)
