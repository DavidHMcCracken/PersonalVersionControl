#!/usr/bin/env python3
# testput.py Updated: 2025.04.11.11.25
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Test dv.py put operation and build a specific repository for other scripts 
# to test get, compare, and delete operations.
# *LXA-ODF*PersonalVersionControl.odt*^1DvTesting* LinkXall link
# ----------------------------------------------------------------------
import os, sys, time, shutil

#writeFile ------------------------------------------------
def writeFile(fname, content) :
    with open(fname, 'wt') as f :
        f.write(content)
    time.sleep(0.1)

#rmtree ----------------------------------------------------------
# Remove a directory and all of its files and descendents.
def rmtree(dpath) :
    if os.path.exists(dpath) :
        for f in os.listdir(dpath) :
            fp = dpath + '/' + f
            if os.path.isdir(fp) :
                rmtree(fp)
            else :
                os.remove(fp) 
        os.rmdir(dpath)

#invdv ---------------------------------------------------
def invdv(arg) :
    cmd = '%s %s'%('dv.py' if oswin else './dv.py', arg)
    print("")
    print(cmd)
    os.system(cmd)

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'

# Remove existing x group versions in the repository and delete all .x files
# in CWD in order to create a fresh group with no carryovers.
for vd in os.listdir('bak') :
    if vd[0:1] == 'x' : rmtree('bak/%s'%vd)
os.system('%s *.x'%('del' if oswin else 'rm'))

# Write 1x, 2x, 3x, 4x to 1.x, 2.x, 3.x, 4.x
for idx in range(1,5) :
    writeFile('%d.x'%idx, '%dx'%idx)
# Put .x to x+, which will automatically be x0. Also test optional -put
invdv('x+ .x -put') 

# Add 5.x and 6.x and put to x1 
writeFile('5.x','5x')
writeFile('6.x','6x')
invdv('x+ .x') 

# Add 7.x to x2, 8.x to x3, 9.x to x4, 10.x to x5, 11.x to x6.
# Change 1.x for x2,x4,x6. Thus x1=x0, x3=x2, x5=x4, x6 is unique.
# 1.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x > x2
# 1.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x > x3
# 1.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x > x4
# 1.x, 10.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x > x5
# 1.x, 10.x, 11.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x > x6
for xv in range(7,12) :
    writeFile('%d.x'%xv, '%dx'%xv)
    if xv%2 == 1 : 
        writeFile('1.x', '1-%d-x'%xv) # Change 1.x
    # xv 7-11 -> versions x2-x6
    if not oswin : time.sleep(1.0)
    invdv('x+ .x') 

# Test VERSION + incremental with no filter. This would normally ask the user 
# to  confirm the creation of x7 even though files are identical to x6 but @ Y 
# clause simulates the user response to facilitate regression testing.
invdv('+ .x @ Y')

#================  Regression Test ===========================
# If invoked by another test script to establish the standard bak\x0-x7 versions
# then don't clutter the output with regression verification or special tests.
if len(sys.argv) > 1 : exit(0) 

errors = 0
#testver ---------------------------------------------
# Test a version directory for files and vdict content. Print a list of the 
# files and the dictionary. If they match the expected patterns, print that 
# they are correct. If not then print that they are wrong and increment global 
# errors.
# Arguments:
#- vdir is the directory path
#- vlist is a list of the expected file names
#- vdic is the expected dictionary.
# ................................................................
def testver(vdir, vlist, vdic) :
    global errors
    print('\n%s'%vdir, end=': ')
    dirlist = os.listdir(vdir)
    dirlist.sort()
    if dirlist != vlist :
        errors += 1
        res = 'wrong'
    else : 
        res = 'correct'
    print('%s is %s'%(str(dirlist),res))
    with open('%s/vdict'%vdir, 'rt') as f : dic = f.read()
    print(dic, end = ' is ')
    if dic != vdic :
        errors += 1
        print('wrong')
    else :
        print('correct')

testver('bak/x0', ['1.x', '2.x', '3.x', '4.x', 'vdict'], 
'{"1.x": [3646614595, "x0"], "2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"]}')

testver('bak/x1', ['5.x', '6.x', 'vdict'], 
'{"1.x": [3646614595, "x0"], "2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"]}')

testver('bak/x2', ['1.x', '7.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "1.x": [1475035452, "x2"]}')

testver('bak/x3', ['8.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "1.x": [1475035452, "x2"], "8.x": [144201482, "x3"]}')

testver('bak/x4', ['1.x', '9.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "1.x": [1567976502, "x4"]}')

testver('bak/x5', ['10.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "1.x": [1567976502, "x4"], "10.x": [1534105928, "x5"]}')

testver('bak/x6', ['1.x', '11.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "10.x": [1534105928, "x5"], "11.x": [1114351625, "x6"], "1.x": [1417620892, "x6"]}')
# x6 has 11.x and its own version of 1.x.

testver('bak/x7', ['vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x3"], "9.x": [293824075, "x4"], "10.x": [1534105928, "x5"], "11.x": [1114351625, "x6"], "1.x": [1417620892, "x6"]}')
# This is identical to the x6 dictionary because no files have changed.

# ------------------------ Special Tests ---------------------------------
#testdir --------------------------------------------------
# Compare contents of the given directory to expected, displaying the sorted
# directory list as "correct" or "wrong". If they are not equal then increment 
# global error count for regression testing.
# Return nothing
# Arguments:
#- dir string is directory
#- want is a sorted (alphabetic) list of the expected contents.
# ............................................................
def testdir(dir, want) :
    global errors
    dlist = os.listdir(dir)
    dlist.sort()
    print(dlist, end = ' is ')
    if dlist == want :
        print('correct')
    else :
        print('wrong')
        errors += 1

print('\n---------- Test alternative repository ---------------')
rmtree('dvalt')
invdv('dvalt/x7 .x')
testdir('dvalt/x7', 
['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x', 'vdict'])

print('\n---------- Test put exclusion -------------')
invdv('xx -[1.x,3.x,5.x] .x @ Y Y') # @ Y Y may  not be needed because xx does not exist.
testdir('bak/xx', ['10.x', '11.x', '2.x', '4.x', '6.x', '7.x', '8.x', '9.x', 'vdict'])
rmtree('bak/xx')

print('\n%d errors'%errors)    
exit(errors)
