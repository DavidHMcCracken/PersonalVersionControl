#!/usr/bin/env python3
# testdels.py Updated: 2025.04.16.13.16
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Test dv.py del operation with shift. testdel.py tests del without shift.
# *LXA-ODF*PersonalVersionControl.odt*^3DvDeleteTest* LinkXall link
#
# For each general test, testput.py is invoked once (by prepx) to provide a 
# consistent initial condition. It is not invoked at the end, leaving the 
# repository in a condition that causes other tests to report errors. 
# ----------------------------------------------------------------------
import os, filecmp, sys, json
errors = 0

#writeFile ------------------------------------------------
def writeFile(fname, content) :
    with open(fname, 'wt') as f :
        f.write(content)

#dirf --------------------------------------------------------------
# Test whether a directory contains exactly the files in a list.
def dirf(dir, flist) :
    global errors
    dirlist = os.listdir(dir)
    dirlist.sort()
    if dirlist == flist :
        cond = 'correct'
    else :
        cond = 'wrong'
        errors += 1
    print('%s: %s is %s'%(dir,dirlist,cond))

#testver ---------------------------------------------
# Test a version directory for files and vdict content. Print a list of the 
# files and the dictionary. If they match the expected patterns, print that 
# they are correct. If not then print that they are wrong and increment global 
# errors.
# Arguments:
#- vdir is the directory path
#- vlist is a list of the expected file names
#- vdic is the expected dictionary.
# ................................................................
def testver(vdir, vlist, vdic) :
    global errors
    dlist = os.listdir(vdir)
    dlist.sort()
    if dlist != vlist :
        match = 'wrong'
        errors += 1
    else :
        match = 'correct'
    print('\n%s: %s is %s'%(vdir, dlist, match))
    with open(vdir + '/vdict', 'rt') as f : dic = f.read()
    print(dic, end = ' is ')
    if dic != vdic :
        errors += 1
        print('wrong')
    else :
        print('correct')

#execmd ----------------------------------------------------
# Display and execute the given command.
def execmd(cmd) :
    print('\n%s'%cmd)
    os.system(cmd if oswin else './%s'%cmd)

#prepx ------------------------------------------------------------
# Called before each invocation of dv-del to prepare a consistent group 
# regardless of preceding tests.
def prepx() :
    print('\n--- Make fresh x0-x6 group ---', end="")
    execmd('testput.py quiet')

# norefs, preget, and postget all take a list of version numbers. The caller 
# may pass a literal list or use range to make it. All list elements exist but 
# if range is used to make it, the upper limit is exclusive.

#norefs -----------------------------------------------------
# Add noref file to version directories.
# Argument vers lists the versions to be deleted. This file is added to them to
# test that orphans are saved when the versions are deleted. 
# Each version name is x?. The file is "noref" for all but contains x?noref to 
# identify its origin.
# ..............................................................
def norefs(vers) :
    for idx in vers :
        writeFile('bak/x%d/noref'%idx, 'x%dnoref'%idx)
   
#preget --------------------------------------------------
# dv-get each version to its named directory (x?) under CWD/dspre. 
# Argument vers lists the versions after the deleted range (before deletion).
# These versions will not be deleted but their names and dictionaries will 
# change and they will inherit referenced files from deleted versions.
# ...............................................................
def preget(vers) :
    for idx in vers :
        execmd('dv.py x%d -get dspre/x%d @ Y'%(idx,idx))

#postget --------------------------------------------------
# dv-get each version and compare its content to its pre-deletion content.
# Argument vers lists the versions by their new number. Integer shift is
# the count of deleted version. new number + shift identifies a version's
# original name captured by preget.
# Pre- and post-deletion content should be identical even though some
# referenced file sources will change.
# At one extreme, errors could be incremented only once per general test even 
# if more than one version is erroneous. At the other extreme, it could be 
# incremented at every error in every tested version. This is in the middle, 
# counting each erroneous version only once even if it contains multiple 
# errors.
# The contents of each shifted (new) version are tested against its original
# contents using dv-cmp. It would be faster to do the testing here, not only
# because invoking dv is less efficient but also because the only way to 
# determine the results is to redirect its display into a file and then
# parse the file. However, dv-cmp does a thorough comparison with details
# that can help identify the cause of errors.
# .................................................................
def postget(vers,shift) :
    global errors
    for idx in vers :
        err = False
        #writeFile('dspre/x%d/test'%(idx+shift), 'test') # Test missing.
        #writeFile('dspre/x%d/1.x'%(idx+shift), 'test') # Test mismatch.
        execmd('dv.py x%d -cmp dspre/x%d > cmpres'%(idx,idx+shift))
        with open('cmpres','rt') as f : res = f.readlines()[1:]
        for ln in res :
            print(ln, end = "")
            if ln.find('MATCH') != 0 : err = True
        if err : errors += 1

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'
# os.system('testput.py' if oswin else './testput.py') 

#DeleteX0 -----------------------------------------------
prepx()
# dv x0 -ref shows that all files are referenced by later non-deleted versions.
norefs([0]) # Add a noref file for testing orphan capture.
preget(range(1,7)) # x1-x6
print('========== Test delete-shift version x0 ============ ', end = "")
execmd('dv.py x0 -del x0 dead @ Y') # Y del ver x0, rm x0, shift, clear dead

testver('bak/x0', ['1.x', '2.x', '3.x', '4.x', '5.x', '6.x', 'vdict'], 
'{"1.x": [3646614595, "x0"], "2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"]}')

testver('bak/x1', ['1.x', '7.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"], "7.x": [2399161285, "x1"], "1.x": [1475035452, "x1"]}')

testver('bak/x2', ['8.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"], "7.x": [2399161285, "x1"], "1.x": [1475035452, "x1"], "8.x": [144201482, "x2"]}')

testver('bak/x3', ['1.x', '9.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"], "7.x": [2399161285, "x1"], "8.x": [144201482, "x2"], "9.x": [293824075, "x3"], "1.x": [1567976502, "x3"]}')

testver('bak/x4', ['10.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"], "7.x": [2399161285, "x1"], "8.x": [144201482, "x2"], "9.x": [293824075, "x3"], "1.x": [1567976502, "x3"], "10.x": [1534105928, "x4"]}')

testver('bak/x5', ['1.x', '11.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"], "7.x": [2399161285, "x1"], "8.x": [144201482, "x2"], "9.x": [293824075, "x3"], "10.x": [1534105928, "x4"], "11.x": [1114351625, "x5"], "1.x": [1417620892, "x5"]}')
print()

postget(range(0,6), 1) # Test new x0-x5 against original x1-x6
print()
dirf('dead',['x0-noref'])
print('------------------------------------------------------------')

#DeleteX2 -----------------------------------------------
prepx()
# dv x2 -ref shows that all of its files are referenced by undeleted versions.
norefs([2]) # Add noref to x2. 
preget(range(3,7)) # x3 - x6

print('============ Test delete-shift version x2 ==========', end = "")
execmd('dv.py x2 -del x2 dead @ Y') # Y del ver, rm dir, shift, clear dead

testver('bak/x0', ['1.x', '2.x', '3.x', '4.x', 'vdict'], 
'{"1.x": [3646614595, "x0"], "2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"]}')

testver('bak/x1', ['5.x', '6.x', 'vdict'], 
'{"1.x": [3646614595, "x0"], "2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"]}')

testver('bak/x2', ['1.x', '7.x', '8.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "1.x": [1475035452, "x2"], "8.x": [144201482, "x2"]}')

testver('bak/x3', ['1.x', '9.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x2"], "9.x": [293824075, "x3"], "1.x": [1567976502, "x3"]}')

testver('bak/x4', ['10.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x2"], "9.x": [293824075, "x3"], "1.x": [1567976502, "x3"], "10.x": [1534105928, "x4"]}')

testver('bak/x5', ['1.x', '11.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x1"], "6.x": [2518383236, "x1"], "7.x": [2399161285, "x2"], "8.x": [144201482, "x2"], "9.x": [293824075, "x3"], "10.x": [1534105928, "x4"], "11.x": [1114351625, "x5"], "1.x": [1417620892, "x5"]}')
print()

postget(range(2,6), 1) # Test new x2-x5 against original x3-x6
print()
dirf('dead',['x2-noref'])
# ----------------------------------------------------------------

#DeleteX0-X3 -----------------------------------------------
prepx()
# dv x0-x3 -ref shows x0/1.x < x1 and x2/1.x < x3. These will be orphans. All 
# other files in deleted versions are referenced by later non-deleted versions.
norefs(range(0,4)) # add noref file to x0-x3. 
preget([4,5,6])
print('=========== Test delete-shift versions x0 through x3 ===========', end = "")
execmd('dv.py x0 -del x3 dead @ Y') # Y del vers, rm dirs, shift, clear dead

testver('bak/x0', ['1.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"], "7.x": [2399161285, "x0"], "8.x": [144201482, "x0"], "9.x": [293824075, "x0"], "1.x": [1567976502, "x0"]}')

testver('bak/x1', ['10.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"], "7.x": [2399161285, "x0"], "8.x": [144201482, "x0"], "9.x": [293824075, "x0"], "1.x": [1567976502, "x0"], "10.x": [1534105928, "x1"]}')

testver('bak/x2', ['1.x', '11.x', 'vdict'], 
'{"2.x": [4067934080, "x0"], "3.x": [3949760193, "x0"], "4.x": [2754418694, "x0"], "5.x": [3174443335, "x0"], "6.x": [2518383236, "x0"], "7.x": [2399161285, "x0"], "8.x": [144201482, "x0"], "9.x": [293824075, "x0"], "10.x": [1534105928, "x1"], "11.x": [1114351625, "x2"], "1.x": [1417620892, "x2"]}')
print()

postget([0,1,2], 4) # Test new x0-x2 against original x4-x6
print()
dirf('dead',['x0-1.x', 'x0-noref', 'x1-noref', 'x2-1.x', 'x2-noref', 'x3-noref']) 
print('------------------------------------------------------------')
 
print('\n%d errors'%errors)
exit(errors)
