#!/usr/bin/env python3
# testbv.py  Updated: 2025.04.16.13.45
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Test bv.py 
# *LXA-ODF*PersonalVersionControl.odt*^1Testing* LinkXall link
# ----------------------------------------------------------------------
import os, shutil, filecmp, sys

#writeFile -------------------------------------------------
# Create or overwrite a file with the given content.
# fpath and content arguments are both single strings. content can comprise
# multiple lines by embedded newlines (\n).
# ......................................................
def writeFile(fpath, content) :
    with open(fpath, 'wt') as f :
        f.write(content)

#rmtree ----------------------------------------------------------
# Remove a directory and all of its files and descendents.
def rmtree(dpath) :
    if os.path.exists(dpath) :
        for f in os.listdir(dpath) :
            fp = dpath + '/' + f
            if os.path.isdir(fp) :
                rmtree(fp)
            else :
                os.remove(fp) 
        os.rmdir(dpath)

#execmd ----------------------------------------------------
# Display and execute the given command.
def execmd(cmd) :
    print('\n%s'%cmd)
    os.system(cmd if oswin else './%s'%cmd)

#testcmd -------------------------------------------------------------
# Execute the given bv command with console output redirected into a file, 
# which is compared to the given list of expected lines. The command and 
# actual list are displayed with the comment "correctly" if the lists match or 
# "wrong" if they don't (which also increments errors). 
# Arguments:
#- arg is the command line arglist presented to dv.
#- expect is a list of the expected output lines.
#- skip is the number of output lines to skip. By default this is 1 in order to
# ignore the first line of bv-cmp, which tells absolute paths of the two files
# being compared. It is an argument to generalize this function.
# ...................................................................
def testcmd(arg,expect,skip=1) :
    global errors
    os.system('%s %s > cmpres'%('bv.py' if oswin else './bv.py', arg))
    with open('cmpres','rt') as f : res = f.readlines()[skip:]
    if res == expect :
        result = 'correctly'
    else :
        result = 'wrong'
        errors += 1
    print('\n%s %s produces'%('bv.py %s'%arg, result))
    for line in res : print(line, end = "")

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'

errors = 0

#PUT -----------------------------------------------------------------
# Remove existing x group versions in the repository and delete all .x files
# in CWD in order to create a fresh group with no carryovers.
for vd in os.listdir('bak') :
    if vd[0:2] == 'bx' : rmtree('bak/%s'%vd)
for f in os.listdir() :
    if f[-2:] == ".x" : os.remove(f)

# Write 1x, 2x, 3x, 4x to 1.x, 2.x, 3.x, 4.x
for idx in range(1,5) :
    writeFile('%d.x'%idx, '%dx'%idx)
# Put .x to bx+, which will automatically be bx0.
print('--- bx0 ---')
execmd('bv.py bx+ .x')

# Add 5.x and 6.x and put to bx1. Coincidentally, verify -put OPERATION. 
writeFile('5.x','5x')
writeFile('6.x','6x')
print('--- bx1 ---')
execmd('bv.py bx+ .x -put')

# Add 7.x to x2, 8.x to x3, 9.x to x4, 10.x to x5, 11.x to x6.
# Change 1.x for bx2,bx4,bx6. Thus bx1=bx0, bx3=bx2, bx5=bx4, bx6 is unique.
# 1.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x > bx2
# 1.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x > bx3
# 1.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x > bx4
# 1.x, 10.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x > bx5
# 1.x, 10.x, 11.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x > bx6
for xv in range(7,12) :
    writeFile('%d.x'%xv, '%dx'%xv)
    if xv%2 == 1 :  
        writeFile('1.x', '1-%d-x'%xv) # Change 1.x
    print('--- bx%d ---'%(xv-5)) # xv 7-11 -> versions bx2-bx6
    execmd('bv.py bx+ .x')

# VERSION + incremental with no filter. This will ask user to confirm the
# creation of bx7 even though files are identical to bx6.
execmd('bv.py + .x @ Y') # Answer Y to create version with identical files.

# ===================== TESTS =========================

#testdir --------------------------------------------------
# Compare contents of the given directory to expected, displaying the sorted
# directory list as "correct" or "wrong". If they are not equal then increment 
# global error count for regression testing.
# Return nothing
# Arguments:
#- dir string is directory
#- want is a sorted list of the expected contents.
def testdir(dir, want) :
    global errors
    dlist = os.listdir(dir)
    dlist.sort()
    print(dlist, end = ' is ')
    if dlist == want :
        print('correct')
    else :
        print('wrong')
        errors += 1

print('\n================== Check Put Results ===================')
testdir('bak/bx0', ['1.x', '2.x', '3.x', '4.x'])
testdir('bak/bx1', ['1.x', '2.x', '3.x', '4.x', '5.x', '6.x'])
testdir('bak/bx2', ['1.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x'])
testdir('bak/bx3', ['1.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x']) 
testdir('bak/bx4', 
['1.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x']) 
testdir('bak/bx5', 
['1.x', '10.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x'])
testdir('bak/bx6', 
['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x'])    
testdir('bak/bx7', 
['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x'])

print('Compare 1.x in bx0/bx1, bx1/bx2, bx2/bx3, bx3/bx4, bx4/bx5, bx5/bx6, bx6/bx7')
# Expect T,F,T,F,T,F,T
for idx in range(7) :
    same = filecmp.cmp('bak/bx%d/1.x'%idx, 'bak/bx%d/1.x'%(idx+1))
    cmpres = (1 if same else 0)^(idx%2)
    if cmpres == 0 : errors += 1
    print('bx%d vs bx%d matching 1.x %s is %s'%(idx, idx+1, same, \
                                ('correct' if cmpres == 1 else 'wrong')))

print('\n------- Test put to alternative repository --------')
rmtree('bvalt')
execmd('bv.py bvalt/x7 .x')
testdir('bvalt/x7', 
['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x'])

print('\n---------- Test put exclusion -------------')
execmd('bv.py xx -[1.x,3.x,5.x] .x @ Y Y')
testdir('bak/xx', ['10.x', '11.x', '2.x', '4.x', '6.x', '7.x', '8.x', '9.x'])

#CMP -----------------------------------------------------------------
print('\n==================== TEST CMP ===================')
testcmd('bx0 -cmp bx1',
['MATCH: 1.x, 2.x, 3.x, 4.x\n', 
'----In bx1 but not in bx0: 5.x, 6.x\n'])

testcmd('bx1 -cmp bx0',
['MATCH: 1.x, 2.x, 3.x, 4.x\n',
'MISSING in bx0: 5.x, 6.x\n'])

# Single Mismatch VERSION newer than OTHER version
testcmd('bx4 -cmp bx0',
['MATCH: 2.x, 3.x, 4.x\n', 
'MISMATCH: bx4/1.x newer than bx0/1.x\n',
'MISSING in bx0: 5.x, 6.x, 7.x, 8.x, 9.x\n'])

# Single Mismatch VERSION older than OTHER version
testcmd('bx0 -cmp bx4',
['MATCH: 2.x, 3.x, 4.x\n', 
'MISMATCH: bx0/1.x older than bx4/1.x\n',
'----In bx4 but not in bx0: 5.x, 6.x, 7.x, 8.x, 9.x\n'])

testcmd('bx5 -cmp bx4',
['MATCH: 1.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x\n',
'MISSING in bx4: 10.x\n'])

# Single mismatch VERSION-ref older than OTHER version
testcmd('bx5 -cmp bx6', 
['MATCH: 10.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x\n',
'MISMATCH: bx5/1.x older than bx6/1.x\n',
'----In bx6 but not in bx5: 11.x\n'])

# Single mismatch VERSION newer than OTHER version
testcmd('bx6 -cmp bx5', 
['MATCH: 10.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x\n', 
'MISMATCH: bx6/1.x newer than bx5/1.x\n', 
'MISSING in bx5: 11.x\n'])

# File system changes to test OTHER as directory.
shutil.rmtree('bvtest', ignore_errors=True)
shutil.copytree('bak/bx6','bvtest/bx6')
# All match to OTHER directory
testcmd('bx6 -cmp bvtest/bx6',
['MATCH: 1.x, 10.x, 11.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x\n'])

shutil.copytree('bak/bx0', 'bvtest/bx0')
# Single Mismatch VERSION newer than OTHER directory
testcmd('bx6 -cmp bvtest/bx0',
['MATCH: 2.x, 3.x, 4.x\n', 
'MISMATCH: bx6/1.x newer than bvtest/bx0/1.x\n',
'MISSING in bvtest/bx0: 10.x, 11.x, 5.x, 6.x, 7.x, 8.x, 9.x\n'])

# Copy bx6 version to testbv/x666 and add some new files
shutil.copytree('bak/bx6', 'bvtest/x666')
for name in ('one', 'two', 'three') : writeFile('bvtest/x666/%s'%name,name)
testcmd('bx6 -cmp bvtest/x666',
['MATCH: 1.x, 10.x, 11.x, 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x\n',
'----In bvtest/x666 but not in bx6: one, three, two\n'])

# Multiple Mismatch and VERSION older than OTHER directory
for f in ('1.x', '2.x', '3.x', '4.x', '5.x') : writeFile('bvtest/x666/%s'%f,
'new %s'%f)
testcmd('bx6 -cmp bvtest/x666',
['MATCH: 10.x, 11.x, 6.x, 7.x, 8.x, 9.x\n', 
'MISMATCH:\n',
'  bx6/1.x older than bvtest/x666/1.x\n',
'  bx6/2.x older than bvtest/x666/2.x\n',
'  bx6/3.x older than bvtest/x666/3.x\n',
'  bx6/4.x older than bvtest/x666/4.x\n',
'  bx6/5.x older than bvtest/x666/5.x\n',
'----In bvtest/x666 but not in bx6: one, three, two\n'])

print('\n%d errors'%errors)    
exit(errors)

