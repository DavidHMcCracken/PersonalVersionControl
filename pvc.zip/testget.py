#!/usr/bin/env python3
# testget.py  Updated: 2025.04.11.12.48
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Test dv.py get operation
# *LXA-ODF*PersonalVersionControl.odt*^3DvGetTest* LinkXall link
#
# testput must have previously executed to set up the repository. It need
# not execute again unless testdel executes.
# ----------------------------------------------------------------------
import os, stat, filecmp, shutil, sys
errors = 0
cwd = os.getcwd()

#rmtree ----------------------------------------------------------
# Remove a directory and all of its files and descendents.
def rmtree(dpath) :
    if os.path.exists(dpath) :
        for f in os.listdir(dpath) :
            fp = dpath + '/' + f
            if os.path.isdir(fp) :
                rmtree(fp)
            else :
                os.remove(fp) 
        os.rmdir(dpath)

#writeFile ------------------------------------------------
def writeFile(fname, content) :
    with open(fname, 'wt') as f :
        f.write(content)

#cmpdirs --------------------------------------------------
# Compare the files in two directories.
# Return tuple of three lists, match, mismatch, and missing files.
# Arguments:
#- d1 and d2 are the directories to be compared. These may be paths
# relative to CWD or absolute. If either is missing, an error message is
# displayed and all three return lists will be empty.
#- nodic bool default True skips vdict in d1 because dv-get skips it.
# .................................................................  
def cmpdirs(d1, d2, nodic = True) :
    match = []
    mismatch = []
    missing = []
    print('Compare %s to %s (%s vdict)'%(d1,d2,'excluding' if nodic else "including"))
    if not os.path.exists(d1) :
        print('%s missing'%d1)
    elif not os.path.exists(d2) :
        print('%s missing'%d2)
    else :
        dlist = os.listdir(d1)
        dlist.sort()
        for f in dlist :
            if nodic and f == 'vdict' : continue
            f1 = '%s/%s'%(d1,f)
            if os.path.isfile(f1) :
                f2 = '%s/%s'%(d2,f)
                if not os.path.exists(f2) :
                    missing.append(f)
                elif filecmp.cmp(f1, f2) :
                    match.append(f)
                else :
                    mismatch.append(f)
    return((match,mismatch,missing))

#testres --------------------------------------------------------
# Invoke cmpdirs on the given directories and compare its return (tuple of 
# three lists) to the given expected result. Report whether they are equal
# and, if not, increment the global error count for regression testing.
# Arguments:
#- strings d1 and d1 are the directories.
#- nodic bool is passed through to cmpdirs. If True then dict is skipped.
#- want is the expected three list tuple.
# ...............................................................
def testres(d1,d2,nodic,want) :
    global errors
    cmp = cmpdirs(d1, d2, nodic)
    print('%s is '%str(cmp), end = "")
    if cmp == want :
        print('correct')
    else :
        print('wrong')
        errors += 1

#testdir --------------------------------------------------
# Compare contents of the given directory to expected, displaying the sorted
# directory list as "correct" or "wrong". If they are not equal then increment 
# global error count for regression testing.
# Return nothing
# Arguments:
#- dir string is directory
#- want is a sorted list of the expected contents.
def testdir(dir, want) :
    global errors
    dlist = os.listdir(dir)
    dlist.sort()
    print(dlist, end = ' is ')
    if dlist == want :
        print('correct')
    else :
        print('wrong')
        errors += 1

#execmd ----------------------------------------------------
# Display and execute the given command.
def execmd(cmd) :
    print('\n%s'%cmd)
    os.system(cmd if oswin else './%s'%cmd)

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'
# os.system('testput.py' if oswin else './testput.py') 

# ...................... get a single file ...................
rmtree('gettest')
execmd('dv.py x6 4.x -get gettest')
err = os.listdir('gettest') != ['4.x'] or not filecmp.cmp('gettest/4.x', 'bak/x0/4.x') 
if err : errors += 1
print('gettest/4.x is %s'%('wrong' if err else 'correct'))

# ..............................................................
# get x0 to gettest/x0. Since gettest has been removed dv.py should make the 
# destination path and not ask about clearing. Comparing (including vdict) 
# gettest/x0 to bak/x0 should show no errors but the inverse will show no 
# vdict in gettest/x0 because dv get is supposed to not include this.
execmd('dv.py x0 -get gettest/x0')
testres('gettest/x0', 'bak/x0', False, (['1.x', '2.x', '3.x', '4.x'], [], []))
testres('bak/x0', 'gettest/x0', False, (['1.x', '2.x', '3.x', '4.x'], [], ['vdict']))

# ......................................................................
# get x1 to gettest/x1. Of the 6 files comprising version x1, its directory
# contains only 5.x and 6.x. The rest are referenced to x0. Coincidentally,
# test specifying the destination as absolute path.
execmd('dv.py x1 -get %s/gettest/x1'%cwd)
testres('gettest/x1', 'bak/x1', True, \
(['5.x', '6.x'], [], ['1.x', '2.x', '3.x', '4.x']))
testres('bak/x1', 'gettest/x1', True, (['5.x', '6.x'], [], []))
testres('gettest/x1', 'bak/x0', True, \
(['1.x', '2.x', '3.x', '4.x'], [], ['5.x', '6.x']))
testres('bak/x0', 'gettest/x1', True, (['1.x', '2.x', '3.x', '4.x'], [], []))

# ......................................................................
# get x2 to gettest/x2. Of the 7 files comprising version x2, its directory
# contains only the new file 7.x and its own version of 1.x. 2.x, 3.x, and 4.x
# are referenced to x0. 5.x and 6.x are referenced to x1.
execmd('dv.py x2 -get gettest/x2')
testres('gettest/x2', 'bak/x2', True, (['1.x', '7.x'], [], ['2.x', '3.x', '4.x', '5.x', '6.x']))
testres('bak/x2', 'gettest/x2', True, (['1.x', '7.x'], [], []))
testres('gettest/x2', 'bak/x0', True, (['2.x', '3.x', '4.x'], ['1.x'], ['5.x', '6.x', '7.x']))
testres('bak/x0', 'gettest/x2', True, (['2.x', '3.x', '4.x'], ['1.x'], []))
testres('gettest/x2', 'bak/x1', True, (['5.x', '6.x'], [], ['1.x', '2.x', '3.x', '4.x', '7.x']))
testres('bak/x1', 'gettest/x2', True, (['5.x', '6.x'], [], []))

# ......................................................................
# get x3 to gettest/x3. Of the 8 files comprising version x3, its directory
# contains only the new file 8.x. 2.x, 3.x, and 4.x come from x0; 5.x and 6.x 
# from x1; 1.x and 7.x from x2. 
execmd('dv.py x3 -get gettest/x3')
testres('gettest/x3', 'bak/x3', True, \
(['8.x'], [], ['1.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x']))
testres('bak/x3', 'gettest/x3', True, (['8.x'], [], []))
testres('gettest/x3', 'bak/x0', True, \
(['2.x', '3.x', '4.x'], ['1.x'], ['5.x', '6.x', '7.x', '8.x']))
testres('bak/x0', 'gettest/x3', True, (['2.x', '3.x', '4.x'], ['1.x'], []))
testres('gettest/x3', 'bak/x1', True, \
(['5.x', '6.x'], [], ['1.x', '2.x', '3.x', '4.x', '7.x', '8.x']))
testres('bak/x1', 'gettest/x3', True, (['5.x', '6.x'], [], []))
testres('gettest/x3', 'bak/x2', True, \
(['1.x', '7.x'], [], ['2.x', '3.x', '4.x', '5.x', '6.x', '8.x']))
testres('bak/x2', 'gettest/x3', True, (['1.x', '7.x'], [], []))

# ......................................................................
# get x6 to gettest/x6. Of the 11 files comprising version x6, its directory
# contains only the new file 11.x and its own version of 1.x. 2.x, 3.x, and 4.x
# are referenced to x0, 5.x and 6.x to x1, 7.x to x2, 8.x to x3, 9.x to x4, and
# 10.x to x5.['10.x>1534105928<x5\n', '2.x>4067934080<x0\n', 
# '3.x>3949760193<x0\n', '4.x>2754418694<x0\n', '5.x>3174443335<x1\n', 
# '6.x>2518383236<x1\n', '7.x>2399161285<x2\n', '8.x>144201482<x3\n', 
# '9.x>293824075<x4\n', '1.x>1417620892<x6\n', '11.x>1114351625<x6\n']
execmd('dv.py x6 -get gettest/x6')
testres('gettest/x6', 'bak/x6', True, \
(['1.x', '11.x'], [], ['10.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x']))
testres('bak/x6', 'gettest/x6', True, (['1.x', '11.x'], [], []))
testres('gettest/x6', 'bak/x0', True, \
(['2.x', '3.x', '4.x'], ['1.x'], ['10.x', '11.x', '5.x', '6.x', '7.x', '8.x', '9.x']))
testres('bak/x0', 'gettest/x6', True, (['2.x', '3.x', '4.x'], ['1.x'], []))
testres('gettest/x6', 'bak/x1', True, \
(['5.x', '6.x'], [], ['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '7.x', '8.x', '9.x']))
testres('bak/x1', 'gettest/x6', True, (['5.x', '6.x'], [], []))
testres('gettest/x6', 'bak/x2', True, \
(['7.x'], ['1.x'], ['10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '8.x', '9.x']))
testres('bak/x2', 'gettest/x6', True, (['7.x'], ['1.x'], []))
testres('gettest/x6', 'bak/x3', True, \
(['8.x'], [], ['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '9.x']))
testres('bak/x3', 'gettest/x6', True, (['8.x'], [], []))
testres('gettest/x6', 'bak/x4', True, \
(['9.x'], ['1.x'], ['10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x']))
testres('bak/x4', 'gettest/x6', True, (['9.x'], ['1.x'], []))
testres('gettest/x6', 'bak/x5', True, \
(['10.x'], [], ['1.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x']))
testres('bak/x5', 'gettest/x6', True, (['10.x'], [], []))

# .........................................................................
print('\nTest get to existing directory.')
os.mkdir('gettest/x66')
execmd('dv.py x6 -get gettest/x66')
testres('gettest/x6', 'gettest/x66', True, \
(['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x'], [], []))

execmd('dv.py x0 -get gettest/x66 @ N') # Don't pre-clear
testres('gettest/x6', 'gettest/x66', True, \
(['10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x'], ['1.x'], []))
testres('bak/x0', 'gettest/x66', True, (['1.x', '2.x', '3.x', '4.x'], [], []))

execmd('dv.py x0 -get gettest/x66 @ Y') # Do pre-clear
testres('gettest/x6', 'gettest/x66', True, \
(['2.x', '3.x', '4.x'], ['1.x'], ['10.x', '11.x', '5.x', '6.x', '7.x', '8.x', '9.x']))
testres('bak/x0', 'gettest/x66', True, (['1.x', '2.x', '3.x', '4.x'], [], []))

# ..................................................................
print('\nTest get default to CWD')
os.system('%s *.x'%('del' if oswin else 'rm'))
noxlist = os.listdir()
testres('gettest/x6', '.', True, 
([], [], ['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x']))

execmd('dv.py x0 -get') 
# With blank OTHER dv-get defaults to CWD and does not offer pre-clear.
testres('gettest/x6', '.', True, 
(['2.x', '3.x', '4.x'], ['1.x'], ['10.x', '11.x', '5.x', '6.x', '7.x', '8.x', '9.x']))

execmd('dv.py x6 -get')
testres('gettest/x6', '.', True, 
(['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x'], [], []))

os.system('%s *.x'%('del' if oswin else 'rm'))
if os.listdir() == noxlist :
    print('All non-x files are untouched')
else :
    print('Non-x files have been damaged')
    errors += 1
# ....................................................................
execmd('dv.py x7 .x -get') # Restore .x files to CWD

# .....................................................................
execmd('dv.py xpy .x .py . @ Y') # Put *.x, *.py and files without extension. 
# @ Y = overwrite version xpy Y, delete its existing files Y.
print('\nTest get file filtering')

execmd('dv.py xpy 1.x -get gettest/xpy')# @ Y not needed because of initial rmtree.
testdir('gettest/xpy', ['1.x'])

execmd('dv.py xpy .x -get gettest/xpy @ Y') # Remove existing files Y.
testdir('gettest/xpy',
['1.x', '10.x', '11.x', '2.x', '3.x', '4.x', '5.x', '6.x', '7.x', '8.x', '9.x'])

# The next two will report error if files without extension are added or removed
# from the workspace.
execmd('dv.py xpy . -get gettest/xpy @ Y') # Remove existing files Y.
testdir('gettest/xpy', ['bvcfg', 'cmpres', 'dvcfg'])

execmd('dv.py xpy . 1.x -get gettest/xpy @ Y') # Remove existing files Y.
testdir('gettest/xpy', ['1.x', 'bvcfg', 'cmpres', 'dvcfg'])

# ................................................................
print('\n%d errors'%errors)
exit(errors)
