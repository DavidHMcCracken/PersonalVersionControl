#!/usr/bin/env python3
# testcmp.py  Updated: 2025.04.11.12.28
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Test dv.py cmp operation. This tests all cmp operations except the special 
# case of a single file (the last optional argument in VERSION FILES OPERATION 
# OTHER EXT) because this invokes an interactive program, e.g. Winmerge or 
# Meld, and produces no testable results. To test this manually use e.g: 
# dv x4 -cmp x0 1.x
# *LXA-ODF*PersonalVersionControl.odt*^3DvCmpTest* (LinkXall link)
#
# testput must have previously executed to set up the repository. It need not 
# execute again unless testdel executes.
# ----------------------------------------------------------------------
import os, sys
errors = 0

#writeFile -------------------------------------------------
# Create or overwrite a file with the given content.
# fpath and content arguments are both single strings. content can comprise
# multiple lines by embedded newlines (\n).
# ......................................................
def writeFile(fpath, content) :
    with open(fpath, 'wt') as f :
        f.write(content)

#rmtree ----------------------------------------------------------
# Remove a directory and all of its files and descendents.
def rmtree(dpath) :
    if os.path.exists(dpath) :
        for f in os.listdir(dpath) :
            fp = dpath + '/' + f
            if os.path.isdir(fp) :
                rmtree(fp)
            else :
                os.remove(fp) 
        os.rmdir(dpath)

#execmd ----------------------------------------------------
# Display and execute the given command.
def execmd(cmd) :
    print('\n%s'%cmd)
    os.system(cmd if oswin else './%s'%cmd)

#testcmd -------------------------------------------------------------
# Execute the given dv command with console output redirected into a file, 
# which is compared to the given list of expected lines. The command and 
# actual list are displayed with the comment "correctly" if the lists match or 
# "wrong" if they don't (which also increments errors). 
# Arguments:
#- arg is the command line arglist presented to dv.
#- expect is a list of the expected output lines.
#- skip is the number of output lines to skip. By default this is 1 in order to
# ignore the first line of dv-cmp, which tells absolute paths of the two files
# being compared. It is an argument to generalize this function.
# ...................................................................
def testcmd(arg,expect,skip=1) :
    global errors
    os.system('%s %s > cmpres'%('dv.py' if oswin else './dv.py', arg))
    with open('cmpres','rt') as f : res = f.readlines()[skip:]
    if res == expect :
        result = 'correctly'
    else :
        result = 'incorrectly'
        errors += 1
    print('\n%s %s produces'%('dv.py %s'%arg, result))
    for line in res : print(line, end = "")

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'
# os.system('testput.py' if oswin else './testput.py') 

testcmd('x0 -cmp x1',
['SAME FILE: x0/1.x, x0/2.x, x0/3.x, x0/4.x\n',
'----In x1 but not in x0: 5.x, 6.x\n'])

testcmd('x1 -cmp x0',
['SAME FILE: x0/1.x, x0/2.x, x0/3.x, x0/4.x\n',
'MISSING in x0: 5.x, 6.x\n'])

# Single Mismatch VERSION newer than OTHER version
testcmd('x4 -cmp x0',
['SAME FILE: x0/2.x, x0/3.x, x0/4.x\n', 
'MISMATCH: x4/1.x newer than x0/1.x\n',
'MISSING in x0: 5.x, 6.x, 7.x, 8.x, 9.x\n'])

# Single Mismatch VERSION older than OTHER version
testcmd('x0 -cmp x4',
['SAME FILE: x0/2.x, x0/3.x, x0/4.x\n', 
'MISMATCH: x0/1.x older than x4/1.x\n',
'----In x4 but not in x0: 5.x, 6.x, 7.x, 8.x, 9.x\n'])

testcmd('x5 -cmp x4',
['SAME FILE: x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x, x4/1.x\n',
'MISSING in x4: 10.x\n'])

# Single mismatch VERSION-ref older than OTHER version
testcmd('x5 -cmp x6', 
['SAME FILE: x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x, x5/10.x\n',
'MISMATCH: x5>x4/1.x older than x6/1.x\n',
'----In x6 but not in x5: 11.x\n'])

# Single mismatch VERSION newer than OTHER version-ref
testcmd('x6 -cmp x5', 
['SAME FILE: x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x, x5/10.x\n', 
'MISMATCH: x6/1.x newer than x5>x4/1.x\n', 
'MISSING in x5: 11.x\n'])

testcmd('x6 -cmp x0', 
['SAME FILE: x0/2.x, x0/3.x, x0/4.x\n',
'MISMATCH: x6/1.x newer than x0/1.x\n',
'MISSING in x0: 5.x, 6.x, 7.x, 8.x, 9.x, 10.x, 11.x\n'])

# ........... OTHER directories and new files ...............
# All match to OTHER directory
execmd('dv.py x6 -get gettest/x6 @ Y') # remove existing files Y
testcmd('x6 -cmp gettest/x6',
['MATCH: 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x, 10.x, 11.x, 1.x\n'])

# Single Mismatch VERSION newer than OTHER directory
execmd('dv.py x0 -get gettest/x0 @ Y') # remove existing files Y
testcmd('x6 -cmp gettest/x0',
['MATCH: 2.x, 3.x, 4.x\n', 
'MISMATCH: x6/1.x newer than gettest/x0/1.x\n',
'MISSING in gettest/x0: 5.x, 6.x, 7.x, 8.x, 9.x, 10.x, 11.x\n'])

print('\nGet x6 to gettest/x666, add new files, compare to x6')
execmd('dv.py x6 -get gettest/x666 @ Y') # remove existing files Y 
for name in ('one', 'two', 'three') : writeFile('gettest/x666/%s'%name,name)
testcmd('x6 -cmp gettest/x666',
['MATCH: 2.x, 3.x, 4.x, 5.x, 6.x, 7.x, 8.x, 9.x, 10.x, 11.x, 1.x\n',
'----In gettest/x666 but not in x6: one, three, two\n'])

# Multiple Mismatch and VERSION older than OTHER directory
for f in ('1.x', '2.x', '3.x', '4.x', '5.x') : writeFile('gettest/x666/%s'%f,
'new %s'%f)
testcmd('x6 -cmp gettest/x666',
['MATCH: 6.x, 7.x, 8.x, 9.x, 10.x, 11.x\n', 
'MISMATCH:\n',
'  x6>x0/2.x older than gettest/x666/2.x\n',
'  x6>x0/3.x older than gettest/x666/3.x\n',
'  x6>x0/4.x older than gettest/x666/4.x\n',
'  x6>x1/5.x older than gettest/x666/5.x\n',
'  x6/1.x older than gettest/x666/1.x\n',
'----In gettest/x666 but not in x6: one, three, two\n'])

# .........................................................
# Multiple Mismatch and VERSION (ref and self) older than OTHER version.
# This modifies .x files in CWD. Before doing this do a basline test by
# getting the curent .x file versions to x8 and comparing x4 to x8. The
# 2.x through 9.x put to x8 will be sourced by x0 through x4. 1.x and 11.x
# will be sourced by x6 and 10.x by x5.
execmd('dv.py x8 .x @ Y') # Identical to x7, make anyway Y
testcmd('x4 -cmp x8',
['SAME FILE: x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x\n',
'MISMATCH: x4/1.x older than x8>x6/1.x\n',
'----In x8 but not in x4: 10.x, 11.x\n'])

# This creates new versions of 1.x-5.x in CWD. Then all CWD .x files are put to
# x8. This requires CWD to initially contain 6.x-11.x.
# x4 sources are x0/2.x, x0/3.x, x0/4.x, x1/5.x, x1/6.x, x2/7.x, x3/8.x, x4/1.x, x4/9.x
# With new versions of 1.x, 2.x, 3.x, 4.x, and 5.x, fresh x8 sources will be:
# x5/10.x, x6/11.x, x1/6.x, x2/7.x, x3/8.x, x4/9.x, x8/1.x, x8/2.x, x8/3.x, x8/4.x, x8/5.x
# Compare x4 to x8 should tell:
# both refer to x1/6.x, x2/7.x, x3/8.x, and x4/9.x
# 1.x, 2.x, 3.x, 4.x, and 5.x are mismatched with x4 older in all cases.
# x8 contains 10.x and 11.x that are not in x4.

for f in ('1.x', '2.x', '3.x', '4.x', '5.x') : writeFile('%s'%f,'new %s'%f)
execmd('dv.py x8 .x @ Y') # Overwite x8 Y, delete its existing files Y
testcmd('x4 -cmp x8',
['SAME FILE: x1/6.x, x2/7.x, x3/8.x, x4/9.x\n',
'MISMATCH:\n',
'  x4>x0/2.x older than x8/2.x\n',
'  x4>x0/3.x older than x8/3.x\n',
'  x4>x0/4.x older than x8/4.x\n',
'  x4>x1/5.x older than x8/5.x\n',
'  x4/1.x older than x8/1.x\n',
'----In x8 but not in x4: 10.x, 11.x\n'])

# To avoid polluting other tests, remove version x8 and restore the .x versions
# in CWD prior to the x8 tests.
rmtree('bak/x8') 
execmd('dv.py x7 .x -get')

print('\n%d errors'%errors)
exit(errors)
