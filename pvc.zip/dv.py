#!/usr/bin/env python3
# dv.py  Updated: 2025.08.19.11.32
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Personal version control with forward delta to eliminate duplicates.
# *LXA-ODF*PersonalVersionControl.odt** Only LinkXall can follow this link.
# ----------------------------------------------------------------------
import sys, os, stat, shutil, re, zlib, filecmp, json

#detcmp -------------------------------------------------------------------
# Invoke a program or system function for a detailed comparison of two files. 
# Meld may be available in any system. Winmerge is only available for Windows 
# but it may be preferred. Windows comp is not very informative but is an 
# example of a shell program that requires OS-specific path.
# .......................................................................
def detcmp(f1,f2) :
    if oswin :
        os.system('winmerge %s %s'%(f1,f2))
        #os.system('comp %s %s'%(os.path.normpath(f1),os.path.normpath(f2)))
    else :
        os.system('meld %s %s'%(f1,f2))
 
#accept --------------------------------------------------------------
# Determine whether the file is a typical temporary lock, which should not be
# included in put *.
# Return True if the file does not have a typical lock name.
def accept(fname) : 
    if fname[0:2] == '.#' or fname[0:2] == '.~' : return False 
    return True 
 
#getans ---------------------------------------------------------
# Get actual or simulated user response to query. This serves only to support 
# regression testing. If the command line has a trailing @ clause then anwsers 
# list will be filled with subsequent arguments. If answers is not empty then 
# the currently index answer is returned and the index incremented with wrap 
# around to enable a series to repeat. Otherwise, this is a passive shell 
# around input. See #Command line
# ..................................................................
answers = []
ansidx = 0
def getans(query) :
    global answers, ansidx
    if len(answers) != 0 :
        idx = ansidx
        ansidx += 1
        if ansidx >= len(answers) : ansidx = 0
        return answers[idx]
    return input(query)

#filesByDate --------------------------------------------------------
# Make a list of the files (skipping sub-dirs and links) sorted by date (oldest
# to newest) in the given directory.
# ..........................................................................
def filesByDate(dp) :
    flist = [f for f in os.listdir(dp) if os.path.isfile('%s/%s'%(dp,f))]
    flist.sort(key=lambda f: os.path.getmtime('%s/%s'%(dp,f)),reverse=False)
    return flist

#rmtree ----------------------------------------------------------
# Remove a directory and all of its files and descendents.
def rmtree(dpath) :
    if os.path.exists(dpath) :
        for f in os.listdir(dpath) :
            fp = dpath + '/' + f
            if os.path.isdir(fp) :
                rmtree(fp)
            else :
                os.remove(fp) 
        os.rmdir(dpath)

#filecrc -----------------------------------------------------------------
def filecrc(fname) :
    with open(fname, 'rb') as f:
        buf = f.read()
        return zlib.crc32(buf)

#existerr ----------------------------------------------------------
# If the given path does not exist report error and optionally exit.
# Return: True if the path exists else False.
# Arguments: p (string) is the path. x (bool) is True to exit if the
# path does not exist.
# ............................................................
def existerr(p,x) :
    if not os.path.exists(p) :
        print('%s does not exist'%p)
        if x : exit(1)
        return False
    return True

#verdic -------------------------------------------------------------
# Make a dictionary from a version's vdict file.
# Return dictionary, which is empty if the file does not exist.
# Arguments:
#- vdir string is path (abs or rel) to the version directory.
#- rpt optional boolean (default False) is True to report if the file doesn't exist.
# ............................................................
def verdic(vdir,rpt=False) :
    dic = {}
    dfile = vdir + '/vdict'
    if os.path.exists(dfile) :
        with open(dfile, 'rt') as f :
            dic = json.load(f)
    elif rpt :
        print('%s is missing'%dfile)
    return(dic)

#verlist --------------------------------------------------------
# Make a list of src/file strings from the vdict file's file:[crc,src] items.
# Return dictionary list or None if vdict is missing.
# ...............................................
def verlist(vdir) :
    dfile = vdir + '/vdict'
    if not os.path.exists(dfile) : return
    with open(dfile, 'rt') as f : dic = json.load(f)
    return ['%s/%s'%(v[1],k) for k,v in dic.items()]

#verfile ------------------------------------------------------------
# Determine whether the given file is in the given dictionary list.
# Return string list item that contains the file or "" if none. 
# Arguments:
#- dlist is a list made by verlist from a dictionary. 
#- fname is the file name.
#- ver is the name of the version whose vdict is used to make dlist. This is 
# used only if fname isn't in dlist. If blank then return "". Otherwise, report
# that this version doesn't have fname and exit.
# This does a case-insensitive search of dlist for fname as a user convenience
# but the dlist match is returned as-is, which is especially helpful in Linux.
# ................................................................
def verfile(dlist, fname, ver="") :
    for vf in dlist :
        if '/'+fname.upper() in vf.upper() : return vf
    if ver == "" :
        return ""
    else :
        print('%s does not have %s'%(ver,fname))
        exit(1)

#dicver ----------------------------------------------------------
# Write dictionary to vdict file.
# Arguments: vd is the version/directory name, dic is the dictionary.
def dicver(vd, dic) :
    with open('bak/%s/vdict'%vd, 'wt') as f :
        json.dump(dic,f)

#mkclrdir -----------------------------------------------------------
# Make a new directory (including ancestors if needed) or delete all files in it,
# after asking, if the directory already exists.
def mkclrdir(dpath) :
    if os.path.exists(dpath) :
        flist = os.listdir(dpath)
        if len(flist) > 0 and getans( \
'Do you want remove existing files in %s?[y/n] ' % dpath).upper() == 'Y' :
            for f in os.listdir(dpath) :
                fpath = '%s/%s'%(dpath,f)
                if os.path.isfile(fpath) : os.remove(fpath)
    else :
        os.makedirs(dpath)

#prepgrp ---------------------------------------------------------------
# Fill global grplist with all versions in the group indicated by vname 
# (VERSION). Assign the index in this list of vname to grpbeg and the next 
# index after oparg (OTHER) to grpend. Thus, grplist[grpbeg:grpend] slice is 
# the selected range and grplist[grpend] is the first one after the selected 
# range.
# Return len(grplist) for caller's convenience. This mainly assigns globals
# grglist, grpbeg, and grpend.
# *LXA-ODF*PersonalVersionControl.odt*^3prepgrp*
# ....................................................................  
def prepgrp() :
    global vname,oparg,grplist,grpbeg,grpend
# Interpret VERSION (vname) and OTHER (oparg). Assign root vname with any 
# numeric suffix removed. If oparg is blank then only vname is selected. If 
# oparg is just a number, it is reassigned root + number.
    p = re.search(r'\d+$',vname)
    if p == None :
        root = vname
    else :
        root = vname[0:p.span()[0]]
    if oparg != "" :
        try :
            int(oparg) # if only a number, add it to root.
            oparg = root + oparg
        except ValueError : pass # oparg is not just a number.
        existerr(repdir+oparg,True) # Report and exit if it doesn't exist.

    # Make vname group list, comprising all versions with the same base name.
    if root == vname : # No numeric suffix
        grplist = [vname]
        grpbeg = 0
        grpend = 0
    gap = 0
    x = 0
    while gap < 4 :
        vd = root + str(x)
        if os.path.exists(repdir + vd) :
            if vd == vname :
                grpbeg = len(grplist)
            grplist.append(vd)
            if vd == oparg :
                grpend = len(grplist)
            gap = 0
        else :
            gap += 1
        x += 1
    if oparg == "" : grpend = grpbeg + 1
    return(len(grplist))
# ................ end prepgrp .........................

#ffidx --------------------------------------------------
# Parse the given file filter. Called by PUT and GET for each FILES argument. 
# Return a negative (from end) index used to determine whether a file passes 
# the filter (filename[idx:] == filter) or 0 if the filter doesn't contain a
# '.', in which case it must be a specific file name.
# Argument ff string is the file filter. 
# ................................................................
def ffidx(ff):
    if ff.rfind('.') == 0 : # '.ext' or '.' but not e.g. '.file.ext'
        return - len(ff) # e.g. .=-1, .py = -3
    else :
        return 0

# ====================== START HERE ========================
#globals -----------------------------------------------
oswin = sys.platform.lower()[0:3] == 'win'
cwd = os.getcwd()
repdir = cwd + '/bak/' # Default repository directory
vname = "" # VERSION
fsel = [] # FILES 
oparg = "" # OTHER
extarg = "" # EXTRA
grplist = []
grpbeg = -1
grpend = -1

#Configuration ----------------------------------------------------------
# dvcfg file can redefine the default repdir, vname, and fsel by assigning
# REPDIR, VERSION, and FILES. Command line VERSION and FILES arguments can
# redefine vname and fsel. The VERSION argument can also redefine repdir
# by including a path.
if os.path.exists('dvcfg') :
    with open('dvcfg','rt') as f :
        cfg = {k:v.strip() for L in f.readlines() if L[0] != '#' for k,v in [L.split('=')]}
        arg = cfg.get('REPDIR')
        if arg != None : repdir = arg
        arg = cfg.get('VERSION')
        if arg != None : vname = arg
        arg = cfg.get('FILES')
        if arg != None : fsel = arg.split(' ')

#CommandLine -----------------------------------------------------------
if len(sys.argv) > 1 and sys.argv[1] == '?' :
    print('dv.py 2025.08.19 Forward delta version control. See PersonalVersionControl.odt.')
    print('dv -v = show repository version groups in alpha/time order.')
    print('dv VERSION FILES = put FILES (space-delimited list) into VERSION.')
    print('dv VERSION -get DIR = get VERSION files to DIR.')
    print('dv VERSION -cmp OTHER EXT = compare files in VERSION to OTHER version or directory.')
    print(' EXT is optional file name for detailed comparison.')
    print('dv VERSION -lst = list the files in VERSION.')
    print('dv VERSION -src = show source of each file in VERSION.')
    print('dv VERSION -ref = show references to each file in VERSION.')
    print('dv VERSION -del OTHER EXT = delete versions VERSION through OTHER.')
    print(' EXT is optional directory to receive orphan files in deleted versions.')
    exit()

def showGrp(grp) :
    if len(grp) > 0 :
        print('> ',end = "")
        grp.sort()
        for f in grp : print(f[1],end = " ")
        print("")

if len(sys.argv) > 1 and sys.argv[1].upper() == '-V' : # List repository versions
    print('Repository (%s) groups in alpha/time order:'%repdir)
    vers = [f for f in os.listdir(repdir) if os.path.isdir('%s/%s'%(repdir,f))]
    vers.sort() # Ensure alphabetic order.
    vbase = ""
    grp = []
    for v in vers :
        mt = os.stat('%s/%s'%(repdir,v))[stat.ST_MTIME]
        p = re.search(r'\d+$',v)
        if p == None :
            vb = v # Let non-sequential name be part of the same base sequence.
        else :
            vb = v[0:p.span()[0]]
        if vb != vbase : # Base name change signals end of group.
            showGrp(grp)
            grp = [(mt,v)]
            vbase = vb
        else :
            grp.append((mt,v))
    showGrp(grp) # Needed for last group, which doesn't encounter name change.
    exit()

# dv VERSION FILES = put
# dv VERSION OPERATION OTHER EXT = cmp, src, ref, get, del
# A trailing @ clause facilitates regression testing by simulating user answers
# to action queries. The global answers list is filled with all arguments after
# @ and maxarg is assigned the index of the last normal argument before @.
maxarg = -1 
for idx,arg in enumerate(sys.argv) : 
    if maxarg > -1 : # 0 :
        answers.append(arg)
    elif arg[0] == '@' :
        maxarg = idx - 1
if maxarg == -1 : maxarg = len(sys.argv) - 1

PUT=0 ; CMP=1 ; LST=2 ; SRC=3 ; REF=4 ; GET=5 ; DEL=6
# The default operation is PUT. Others are selected by OPERATION argument. If 
# this is not the last one the next argument is assigned to oparg (argument to
# OPERATION).
op = PUT
opidx = -1
if maxarg > 0 :
    for idx in range(1, maxarg + 1) :
        if sys.argv[idx][0] == '-' :
            arg = sys.argv[idx].upper()
            try : 
                op = ('-PUT', '-P', '-CMP', '-C', '-LST', '-L', '-SRC', '-S', \
                      '-REF', '-R', '-GET', '-G', '-DEL', '-D').index(arg) // 2
                opidx = idx
                if idx < maxarg : oparg = sys.argv[idx + 1]
                break
            except ValueError : pass # It may be a file, e.g. -myFile.
# If the first argument is op, others are either blank or defined by dvcfg.
# If dvcfg has defined VERSION then normalize argv by making vname the
# first argument.
    if op != PUT and idx == 1 :
        if vname != "" :
            sys.argv.insert(1, vname)
            maxarg += 1
    else : 
        vname = sys.argv[1] # If not op then VERSION

# FILES arguments can override FILES defined by dvcfg. They are from [2] to 
# opidx (exclusive) or maxarg (inclusive) the last one before @ clause. If
# op is GET and FILES is empty, fsel defaults to *. 
if opidx > -1 :
    idx = opidx
else :
    idx = maxarg + 1
if idx > 2 :
    fsel = sys.argv[2 : idx]
elif op == GET :
    fsel = ['*']

if opidx > -1 and maxarg > opidx + 1 : extarg = sys.argv[maxarg]

# If VERSION includes path, this path redefines repdir. This enables the command
# line to define an alternate repository, which is normally the default CWD/bak
# or REPDIR defined in dvcfg, which can alternatively include path in VERSION.
i2 = vname.rfind('/')
if i2 == -1 : i2 = vname.rfind('\\')
if i2 > -1 :
    repdir = vname[0:i2] + '/'
    vname = vname[i2 + 1:]

if not os.path.exists(repdir) :
    if op == PUT :
        os.makedirs(repdir)
    else :
        print('Repository directory %s does not exist'%repdir)
        exit(1)

#MostRecentVersion ...................................................
# *LXA-ODF*PersonalVersionControl.odt*^3MostRecentVersion*
verinc = True 
verbase = "" 
# If VERSION argument ends in + then verinc is true and verbase is the 
# argument up to the +, e.g. "odt" if VERSION is "odt+". If VERSION is just + 
# then verbase will be "" and the most recent version directory regardless of 
# name will be taken as the most recent to pass the VERSION filter. If VERSION
# argument does not end in + it might be a specific version in a group. Put 
# will still need most recent in order to read its dictionary. If it  does not 
# have numeric suffix then assign it to verbase; otherwise, assign it with the 
# suffix removed to verbase. 
if len(vname) > 1 and vname[-1] == '+' :
    verbase = vname[0:-1]
elif vname != "" and vname != '+' :
    verinc = False 
    p = re.search(r'\d+$',vname)
    if p == None :
        verbase = vname
    else :
        verbase = vname[0:p.span()[0]]

if op == PUT or op != DEL and verinc :
    mrver = "" # Most recent version name matching verbase pattern.
    mrtim = 0 # mrver directory modified time.
    dlist = os.listdir(repdir)
    if len(dlist) == 0 and verbase == "" :
        vname = 'v0'
    else :
        dlist.sort() # Primary sort is by time but this makes alpha a secondary
# key. This mainly ensures consistent results when a regression test creates 
# sequential versions, e.g. x6 and x7, with the same mod time (note dt >= mrtim)
        for vd in dlist :
            if vd != vname and vd.find(verbase) == 0 :
                pf = repdir + vd
                if os.path.isdir(pf) :
                    dt = os.stat(pf)[stat.ST_MTIME] 
                    if dt >= mrtim :
                        mrtim = dt
                        mrver = vd
        if verinc :
            if mrtim == 0 :
                vname = verbase + '0'
            elif op == PUT : 
# To make the next version name, if the most recent version name has numeric 
# suffix then increment the complete number. Otherwise append 0 to it. 
                p = re.search(r'\d+$',mrver)
                if p != None :
                    vname = mrver[0:p.span()[0]] + str(int(p.group(),10) + 1) 
                else :
                    vname = mrver + '0'
            else : 
                vname = mrver # shortcut for most recent
    mrdir = "" if mrver == "" else repdir + mrver   
vdir = repdir + vname 

if op != PUT : # ------ CMP, LST, SRC, REF, GET,DEL  -------------------
# *LXA-ODF*PersonalVersionControl.odt*^3SrcRefGetCmpDel*
    existerr(vdir, True) # If vdir does not exist, report and exit.
# verlist is called to make a list of VERSION and OTHER dictionaries. It returns
# None if vdict is missing. Missing VERSION vdict is fatal but for OTHER without
# vdict is treated as an ordinary directory.
    flist = verlist(vdir) # VERSION dictionary list. Required for all except DEL
    # but DEL might be able to use it if not missing.
    if op != DEL : 
        if flist == None :
            print('%s missing vdict'%vdir)
            exit(1)
        if oparg == "" or oparg == '.' :
            odir = cwd
        elif op != GET and os.path.exists(repdir + oparg) :
            odir = repdir + oparg
        else :
            odir = oparg

    if op == LST : #LST ---------------------------------------------
# Compact list of the files that comprise this version without their source.
        print('%s comprises %s'%(vname,\
        ', '.join([f[f.rindex('/') + 1:] for f in flist])))

    elif op == SRC : #SRC -----------------------------------------------
# List the files, with their source, that comprise this version
        print('%s sources are %s'%(vname, ', '.join(flist)))

    elif op == REF : #REF ----------------------------------------
        prepgrp()
        refdic = {} # Reference dictionary keys will be 'ver/file' sources found
# in version dictionaries with value a list of these versions. 
        begver = grplist[grpbeg] 
        endver = grplist[grpend-1]
# vname and oparg usually could be used instead of getting begver and endver
# from grplist but they may be incremental and oparg may be blank.
        for ver in grplist[grpbeg + 1:] :
# All group versions after the begin (VERSION) are examined.
            dic = verdic(repdir+ver) # Each item is file:[crc,srcver]
            for k,v in dic.items() :
                if v[1] >= begver and v[1] <= endver and v[1] != ver :
# Only non-self references to versions between VERSION and OTHER are added.
                    vf = '%s/%s'%(v[1],k)
                    if vf in refdic :
                        refdic[vf].append(ver)
                    else :
                        refdic[vf] = [ver]
        for k,v in refdic.items() :
            print('%s < %s'%(k,','.join(v)))
  
        unref = []
        for ver in grplist[grpbeg:grpend] :
            for f in os.listdir(repdir+ver) :
                if f != 'vdict' :
                    vf = '%s/%s'%(ver,f)
                    if not vf in refdic :
                        unref.append(vf)
        if len(unref) > 0 : print('Unreferenced: %s'%', '.join(unref))

    elif op == GET : #GET --------------------------------------------
        if oparg != "" :
            mkclrdir(odir) # This calls getans.
        if '*' in fsel :
            for f in flist :
                print(f, end=', ')
                shutil.copy2(repdir + f, odir)
        else :
            for ffil in fsel :
                idx = ffidx(ffil)
                for f in flist :
                    fname = f[f.rfind('/') + 1:] # strip off src/
                    if fname[idx:] == ffil or idx == -1 and not '.' in fname :
                        print(fname, end=', ')
                        shutil.copy2(repdir + f, odir)
        print()

    elif op == CMP : #CMP ---------------------------------------------
        oplist = verlist(odir) # OTHER dictionary list
        if extarg != "" : # dv v1 -cmp OTHER file. Invoke another program for
# detailed and probably interactive compare of two versions of one file.
            f1 = repdir + verfile(flist,extarg,vname)
            if oplist == None :
                f2 = '%s/%s'%(odir,extarg)
                if not os.path.exists(f2) :
                    print('%s does not exist'%f2)
                    exit(1)
            else :
                f2 = repdir + verfile(oplist,extarg,oparg)
            if f1 == f2 :
                print('Same file %s'%f1)
            else :
                print('Compare %s to %s'%(f1,f2))
                detcmp(f1,f2)
            exit()
        if not os.path.isdir(odir) :
            print('Directory %s does not exist'%odir)
            exit(1)
        print('Compare %s to %s' % (vdir, odir))
        same = []
        match = []
        mismatch = []
        missing = []
        for f in flist : 
            f2 = ""
            if oplist != None and f in oplist : # same ver/file
                same.append(f)
            else :
                fnam = os.path.basename(f) # e.g. x6/11.x -> 11.x
                if oplist != None :
                    vf2 = verfile(oplist,fnam)
                    if vf2 != "" :
                        f2 = repdir + vf2
                        if vf2.find(oparg) == 0 :
                            other = vf2 # e.g. 'x6/1.x'
                        else :
                            other = '%s>%s'%(oparg,vf2) # e.g. 'x7>x6/1.x'
                if f2 == "" :
                    f2 = '%s/%s'%(odir,fnam) # OTHER/file
                    other = f2
                if not os.path.exists(f2) :
                    missing.append(fnam) #other if oplist == None else fnam)
                else :
                    vf = repdir + f
                    if filecmp.cmp(vf,f2) :
                        match.append(fnam)
                    else :
                        mismatch.append('%s %s than %s'%( \
f if f.find(vname) == 0 else '%s>%s'%(vname,f), \
'newer' if os.stat(vf).st_mtime > os.stat(f2).st_mtime else 'older', other))

        other = oparg if odir != cwd else odir 
        if len(same) > 0 :
            print('SAME FILE: %s'%', '.join(same))
        if len(match) > 0 :
            print('MATCH: %s'%', '.join(match))
        if len(mismatch) > 0 :
            print('MISMATCH:%s%s'%(' ' if len(mismatch) == 1 else '\n  ', \
                               '\n  '.join(mismatch)))
        if len(missing) > 0 :
            print('MISSING in %s: %s'%(other, ', '.join(missing)))
# Report files in OTHER that are not in VERSION. 
        if oplist == None : # OTHER is a non-version directory.
            oflist = [f for f in os.listdir(odir) if os.path.isfile('%s/%s'%(odir,f))]
        else : # OTHER is a version. 
            oflist = [f[f.find('/')+1:] for f in oplist]
        oflist.sort() # This is mainly to be consistent for regression testing 
# but it can also reduce user misunderstanding.
        remiss = ', '.join([f for f in oflist if verfile(flist,f) == ""])
        if remiss != "" :
            print('----In %s but not in %s: %s'%(other,vname,remiss))
   
    elif op == DEL : #DEL --------------------------------------------
# *LXA-ODF*PersonalVersionControl.odt*^3DvDel*
        if oparg == "" or oparg == vname :
            ddirs = vdir
            dvers = vname
        else :
            ddirs = '%s through %s'%(vdir,oparg)
            dvers = '%s through %s'%(vname,oparg)
        if getans('Do you want to delete version %s?[y/n] '%dvers).upper() != 'Y' : 
            exit()
        rmdirs = getans('Do you want to remove %s?[y/n] '%ddirs).upper() == 'Y'
        prepgrp()
        shift = 0
        if rmdirs and getans( \
'Do you want to shift the rest down to fill the gap?[y/n] ').upper() == 'Y' :
            shift = grpbeg - grpend

        if extarg != "" : # Request to copy dead-end files to EXT directory.
# Dead-ends are unreferenced files, which are not moved when their version 
# is deleted. Each element of movlist is a list of moved files in a deleted 
# version. After moving the referenced files, before deleting the directories
# go back over them to find any files that are not in the corresponding
# move list, i.e. dead-ends.
            movlist = [[] for idx in range(grpend-grpbeg)]

        # Update versions after the deleted ones
        repdic = {} # Replacement dictionary. 
        for idx in range(grpend,len(grplist)) :
            vname = grplist[idx]
            dic = verdic(repdir+vname, True) # This version's dictionary. Report if missing.
            if len(dic) == 0 : continue # does not exist.
            dchng = False # This dictionary is initially unchanged.
            if shift != 0 : repl = grplist[idx+shift]
            for fname,dval in dic.items() : # file:[crc,src] Note that dval is
# an lval (list reference) and changes to it change dic. fname is an rval.
                src = dval[1]
# If this version is the file src then don't change it unless the versions are 
# being shifted to fill the gap, in which case change it and add to repdic.
                if src == vname : 
                    if shift != 0 :
                        dval[1] = repl
                        dchng = True
                        repdic['%s/%s'%(src,fname)] = repl
                    continue 
                try :
                    srcidx = grplist.index(src)
                except ValueError : 
                    print('%s dictionary bad reference to %s in %s' % \
                    (vname, fname, src))
                    continue
                if srcidx < grpbeg or shift == 0 and srcidx >= grpend : 
                    continue # Reference to undeleted version is ok. This would
# also guard against replacing a version-specific file but that is already 
# avoided by continue if src == vname.

                repk = '%s/%s'%(src,fname) # oldsrc/file key. If this is already
# in the replacement dictionary then change oldsrc to newsrc in this version's 
# dictionary. Otherwise, copy the file, change oldsrc to vname in this version's
# dictionary and add oldsrc/file:vname to the replacement dictionary.
                dchng = True # In either case this version dictionary changes.
                try : 
                    repv = repdic[repk]
                    dval[1] = repv # Change oldsrc to newsrc
                except KeyError : # Not already replaced.
                    shutil.copy2('%s%s/%s'%(repdir,src,fname),'%s%s'%(repdir,vname))
                    src = vname if shift == 0 else repl
                    dval[1] = src 
                    repdic[repk] = src
                    if extarg != "" :
                        movlist[srcidx-grpbeg].append(fname)
            if dchng :
                dicver(vname,dic)

        if extarg != "" :
            mkclrdir(extarg) # This calls getans.
# There is no list of dead-ends. movlist tells, for each version being 
# deleted, the files that have moved because they are referenced. The only way 
# to determine dead-ends, if any, is compare the file list of each version 
# being deleted to the corresponding element of movlist. 
            for i,vml in enumerate(movlist) :
                ver = grplist[grpbeg + i]
                for f in os.listdir(repdir+ver) :
                    if f != 'vdict' and f not in vml : 
                        shutil.copy2('%s%s/%s'%(repdir,ver,f),
                                     '%s/%s-%s'%(extarg,ver,f))
        if rmdirs :
            for idx in range(grpbeg, grpend) :
                rmtree(repdir + grplist[idx])
        if shift != 0 :
            for idx in range(grpend,len(grplist)) :
                os.rename('%s%s'%(repdir,grplist[idx]), \
                          '%s%s'%(repdir,grplist[idx+shift]))
    exit()

#PUT ---------------------------------------------------------------
# *LXA-ODF*PersonalVersionControl.odt*^3DvPut*
if os.path.exists(vdir) :
    flist = os.listdir(vdir)
    print(vdir + (' is empty' if len(flist) < 1 else \
    ' currently contains ' + ', '.join(flist)))
    if getans('Do you want to overwrite it?[y/n] ').upper() != 'Y' : exit()
    if len(flist) > 0 and getans('Delete its current files?[y/n] ').upper() == 'Y' :
        fp = vdir + '/'
        for f in flist : os.remove(fp + f)
flist = filesByDate(cwd)
# flist contains all files in this directory. If no file filters are specified 
# then all of these files are included after asking. If FILES = '*' then they
# are included without asking.
if len(fsel) == 0 : 
    if getans('Do you want to record all files here in %s?[y/n] '%vdir).upper() \
    != 'Y' : exit()
    fsel = ['*']

src = list()
fex = list() # File exclusion list
# Go through the file filter list, recording all files in this directory that 
# pass each filter. If a filter is "*" record all files and stop processing 
# the filter list, as any other filters are superfluous.
for ffil in fsel : 
    if len(ffil) > 2 and ffil[0:2] == '-[' and ffil[-1:] == ']' :
        fex = ffil[2:-1].split(',')
        continue
    if ffil == '*' : # All files
        for f in flist :
            if f in fex : continue
            if accept(f) : src.append(f)
        break # ffil in fsel. Any other filters are superfluous.
    idx = ffidx(ffil)
# Copy fully named file or all that pass .ext filter.
    for f in flist :
        if f in fex : continue
        if f[idx:] == ffil or idx == -1 and not '.' in f :
            if idx == 0 : # filter is a complete file name.
                src.append(f)
                break # No need to search for another.
            if accept(f) : 
                src.append(f) # If filter is .ext, include this file only if it 
# does not match an excluded pattern, e.g. .#file.py Emacs lock file.
if len(src) == 0 :
    print("No files pass your filters")
    exit()

mrdic = verdic(mrdir) # Make a dictionary of the most recent version's vdict 

# Add to the new version dictionary each file selected by the FILES filter.
# If the same file (name and CRC) is in the previous version then record this
# as its source. Otherwise, record this version as its source and add it to the
# newfiles list of files that will be copied into this new version directory.

newfiles = [] # New files, which need to copied into this version's directory.
vdict = {} # This version's dictionary
for f in src :
    crc = filecrc(f)
    try : # Exception is cheaper than if dict.in() then dict.get(). 
        v = mrdic[f]
        if v[0] == crc :
            vdict[f] = [crc, v[1] if v[1] != "" else mrver]
            continue
        # Fall through if in previous version but CRC doesn't match.
    except KeyError: pass # It isn't in the dictionary so record it as new.
    newfiles.append(f) 
    vdict[f] = [crc,vname]

if len(newfiles) == 0 and getans( \
'All files are identical to those in %s. Do you want to make %s anyway?[y/n] ' \
               %(mrver,vname)).upper() != 'Y' : exit()
if not os.path.exists(vdir) : os.mkdir(vdir)
for f in newfiles : shutil.copy2(f, vdir)

with open(vdir + '/vdict', 'wt') as vd: json.dump(vdict,vd)

sold = ""
if len(newfiles) > 0 :
    snew = ', '.join(newfiles)
    oldfiles = []
    for f in src :
        if not f in newfiles :
            oldfiles.append(f)
    if len(oldfiles) > 0 :
        sold = '[ %s ] '%', '.join(oldfiles)
else :
    snew = ""
    sold = '[ %s ] '%', '.join(src)
print('%s%s put to %s'%(sold, snew, vdir))

