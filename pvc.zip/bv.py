#!/usr/bin/env python3
# bv.py Updated: 2025.06.05.12.29
#
# Copyright (C) 2025 David McCracken. This program is free software; you can 
# redistribute it and/or modify it under the terms of the GNU General Public 
# License version 3 as published by the Free Software Foundation. It is 
# distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
# PARTICULAR PURPOSE.  See the GNU General Public License 
# (http://www.gnu.org/licenses) for more details.
#
# Simple backup version control. Copy files to a version-named directory under 
# the repository directory, which is CWD/bak unless a different repdir 
# directory is named in a project-specific configuration file (CWD/bvcfg) or 
# command line VERSION argument includes path.
# -------------------------------------------------------------------------
import sys, os, stat, shutil, re, filecmp 

#detcmp ------------------------------------------------------------------
# Invoke a program or system function for a detailed comparison of two files. 
# Meld may be available in any system. Winmerge is only available for Windows 
# but it may be preferred. Windows comp is uninformative but is an example of 
# a shell program that requires OS-specific path.
# .......................................................................
def detcmp(f1,f2) :
    if oswin :
        os.system('winmerge %s %s'%(f1,f2))
        #os.system('comp %s %s'%(os.path.normpath(f1),os.path.normpath(f2)))
    else :
        os.system('meld %s %s'%(f1,f2))
 
#accept --------------------------------------------------------------
# Determine whether the file is a typical temporary lock, which should not be
# included in put *.
# Return True if the file does not have a typical lock name.
def accept(fname) : 
    if fname[0:2] == '.#' or fname[0:2] == '.~' : return False
    return True
 
#getans ---------------------------------------------------------
# Get actual or simulated user response to action query. This serves only to 
# support regression testing. If the command line has a trailing @ clause then 
# anwsers list will be filled with subsequent arguments. If answers is not 
# empty then the currently index answer is returned and the index incremented 
# with wrap around to enable a series to repeat. Otherwise, this is a passive 
# shell around input. See #Command line
# ..................................................................
answers = []
ansidx = 0
def getans(query) :
    global answers, ansidx
    if len(answers) != 0 :
        idx = ansidx
        ansidx += 1
        if ansidx >= len(answers) : ansidx = 0
        return answers[idx]
    return input(query)

# ====================== START HERE ========================
oswin = sys.platform.lower()[0:3] == 'win'
cwd = os.getcwd()
repdir = cwd + '/bak/' # Default repository directory
vname = "" # VERSION
fsel = [] # FILES 
oparg = "" # OTHER
extarg = "" # EXTRA
#Configuration --------------------------------------------------------
# bvcfg file can redefine the default repdir, vname, and fsel by assigning
# REPDIR, VERSION, and FILES. Command line VERSION and FILES arguments can
# redefine vname and fsel. The VERSION argument can also redefine repdir
# by including a path.
if os.path.exists('bvcfg') :
    with open('bvcfg','rt') as f :
        cfg = {k:v.strip() for L in f.readlines() if L[0] != '#' for k,v in [L.split('=')]}
        arg = cfg.get('REPDIR')
        if arg != None : repdir = arg
        arg = cfg.get('VERSION')
        if arg != None : vname = arg
        arg = cfg.get('FILES')
        if arg != None : fsel = arg.split(' ')

#CommandLine -----------------------------------------------------------
if len(sys.argv) > 1 and sys.argv[1] == '?' :
    print('bv.py 2025.06.05 Backup version control. See PersonalVersionControl.odt.')
    print('bv -v = show repository version groups in alpha/time order.')
    print('bv VERSION FILES = put FILES (space-delimited list) into VERSION.')
    print('bv VERSION -cmp OTHER EXT = compare files in VERSION to OTHER version or directory.')
    print(' EXT is optional file name for detailed comparison.')

    exit()

def showGrp(grp) :
    if len(grp) > 0 :
        print('> ',end = "")
        grp.sort()
        for f in grp : print(f[1],end = " ")
        print("")

if len(sys.argv) > 1 and sys.argv[1].upper() == '-V' : # List repository versions
    print('Repository (%s) groups in alpha/time order:'%repdir)
    vers = [f for f in os.listdir(repdir) if os.path.isdir('%s/%s'%(repdir,f))]
    vers.sort() # Ensure alphabetic order.
    vbase = ""
    grp = []
    for v in vers :
        mt = os.stat('%s/%s'%(repdir,v))[stat.ST_MTIME]
        p = re.search(r'\d+$',v)
        if p == None :
            vb = v # Let non-sequential name be part of the same base sequence.
        else :
            vb = v[0:p.span()[0]]
        if vb != vbase : # Base name change signals end of group.
            showGrp(grp)
            grp = [(mt,v)]
            vbase = vb
        else :
            grp.append((mt,v))
    showGrp(grp) # Needed for last group, which doesn't encounter name change.
    exit()

# bv VERSION FILES = put
# bv VERSION -cmp OTHER EXT = compare VERSION to OTHER. Optional EXT names a
# single file to be compared in detail (detcmp)
# A trailing @ clause facilitates regression testing by simulating user answers
# to action queries. The global answers list is filled with all arguments after
# @ and maxarg is assigned the index of the last normal argument before @.
maxarg = 0
for idx,arg in enumerate(sys.argv) : 
    if maxarg > 0 :
        answers.append(arg)
    elif  arg == '@' : maxarg = idx - 1
if maxarg == 0 : maxarg = len(sys.argv) - 1

PUT=0 ; CMP=1 
# The default operation is PUT. CMP can only be selected by OPERATION argument. 
# If this is not the last one the next argument is assigned to oparg (argument 
# to OPERATION).
op = PUT
opidx = -1
if maxarg > 0 :
    for idx in range(1, maxarg + 1) :
        if sys.argv[idx][0] == '-' :
            arg = sys.argv[idx].upper()
            try : 
                op = ('-PUT', '-P', '-CMP', '-C').index(arg) // 2
                opidx = idx
                if idx < maxarg : oparg = sys.argv[idx + 1]
                break
            except ValueError : pass # It may be a file, e.g. -myFile.
# If the first argument is op, others are either blank or defined by bvcfg.
# If bvcfg has defined VERSION then normalize argv by making vname the
# first argument.
    if op != PUT and idx == 1 :
        if vname != "" :
            sys.argv.insert(1, vname)
            maxarg += 1
    else : vname = sys.argv[1] # If not op then VERSION

# FILES arguments can override FILES defined by bvcfg. They are from [2] to 
# opidx (exclusive) or maxarg (inclusive) the last one before @ clause. 
if opidx > -1 :
    idx = opidx
else :
    idx = maxarg + 1
if idx > 2 :
    fsel = sys.argv[2 : idx]

if opidx > -1 and maxarg > opidx + 1 : extarg = sys.argv[maxarg]

# If VERSION includes path, this path redefines repdir. This enables the command
# line to define an alternate repository, which is normally the default CWD/bak
# or REPDIR defined in bvcfg, which can alternatively include path in VERSION.
i2 = vname.rfind('/')
if i2 == -1 : i2 = vname.rfind('\\')
if i2 > -1 :
    repdir = vname[0:i2] + '/'
    vname = vname[i2 + 1:]

if not os.path.exists(repdir) :
    if op == PUT :
        os.makedirs(repdir)
    else :
        print('Repository directory %s does not exist'%repdir)
        exit(1)

#MostRecentVersion ...................................
# *LXA-ODF*PersonalVersionControl.odt*^3MostRecentVersion*
verinc = True # 1
verbase = "" 
if len(vname) > 1 and vname[-1] == '+' :
    verbase = vname[0:-1]
elif vname != "" and vname != '+' :
    verinc = False # 0
# If VERSION argument ends in + then verinc is true and verbase is the 
# argument up to the +, e.g. "odt" if VERSION is "odt+". If VERSION is just + 
# then verbase will be "" and the most recent version directory regardless of 
# name will be taken as the most recent to pass the VERSION filter. 

mrver = "" # Most recent version name matching verbase pattern.
mrtim = 0 # mrver directory modified time.
if verinc :
    dlist = os.listdir(repdir)
    if len(dlist) == 0 and verbase == "" :
        verbase = 'v' # The first unbased incremental will be v0.
    else :
        dlist.sort() # Primary sort is by time but this makes alpha a secondary 
# key. This mainly ensures consistent results when a regression test creates 
# sequential versions, e.g. x6 and x7, with the same mod time (note dt >= mrtim)
        for vd in dlist :
            if vd != vname and vd.find(verbase) == 0 :
                pf = repdir + vd
                if os.path.isdir(pf) :
                    mt = os.stat(pf)[stat.ST_MTIME] 
                    if mt >= mrtim :
                        mrtim = mt
                        mrver = vd
    if mrtim == 0 :
        vname = verbase + '0'
    elif op == PUT : 
# To make the next version name, if the most recent version name has numeric 
# suffix then increment the complete number. Otherwise append 0 to it. 
        p = re.search(r'\d+$',mrver)
        if p != None :
            vname = mrver[0:p.span()[0]] + str(int(p.group(),10) + 1) 
        else :
            vname = mrver + '0'
    else : # not PUT
        vname = mrver # shortcut for most recent
vdir = repdir + vname

#CMP -------------------------------------------------------
if op == CMP :
    if not os.path.exists(vdir) :
        print('%s does not exist'%vdir)
        exit(1)
    flist = os.listdir(vdir)
    flist.sort() # For consistent display
    if oparg == "" or oparg == '.' :
        odir = cwd
    elif os.path.exists(repdir + oparg) :
        odir = repdir + oparg
    else :
        odir = oparg

    if extarg != "" : # bv v1 -cmp OTHER file
        f1 = '%s/%s'%(vdir,extarg) 
        f2 = '%s/%s'%(odir,extarg)
        if not os.path.exists(f2) :
            print('%s does not exist'%f2)
            exit(1)
        print('Compare %s to %s'%(f1,f2))
        detcmp(f1,f2)
        exit()
    if not os.path.isdir(odir) :
        print('Directory %s does not exist'%odir)
        exit(1)
    print('Compare %s to %s' % (vdir, odir))
    other = oparg if odir != cwd else odir 
    match = []
    mismatch = []
    missing = []
    for f in flist : 
        f1 = '%s/%s'%(vdir,f) 
        f2 = '%s/%s'%(odir,f)
        if not os.path.isfile(f2) :
            missing.append(f)
        elif filecmp.cmp(f1,f2) :
            match.append(f)
        else :
            mismatch.append('%s/%s %s than %s/%s'%(vname,f,'newer' if \
os.stat(f1).st_mtime > os.stat(f2).st_mtime else 'older', other, f))

    if len(match) > 0 :
        print('MATCH: %s'%', '.join(match))
    if len(mismatch) > 0 :
        print('MISMATCH:%s%s'%(' ' if len(mismatch) == 1 else '\n  ', \
                               '\n  '.join(mismatch)))
    if len(missing) > 0 :
        print('MISSING in %s: %s'%(other, ', '.join(missing)))

    # Show all of the files in OTHER that are not in VERSION
    oflist = [f for f in os.listdir(odir) if \
    os.path.isfile('%s/%s'%(odir,f)) and not os.path.isfile('%s/%s'%(vdir,f))]
    oflist.sort() # For consistent display.
    remiss = ', '.join(oflist)
    if remiss != "" :
        print('----In %s but not in %s: %s'%(other,vname,remiss))
    exit(0)

#PUT ---------------------------------------------------
if os.path.exists(vdir) :
    flist = os.listdir(vdir)
    print(vdir + (' is empty' if len(flist) < 1 else \
                  ' currently contains ' + ','.join(flist)))
    if getans('Do you want to overwrite it?[y/n] ').upper() != 'Y' : exit()
    if len(flist) > 0 and getans('Delete its current files?[y/n] ').upper() == 'Y' :
        fp = vdir + '/'
        for f in flist : os.remove(fp + f)

flist = [f for f in os.listdir() if not os.path.isdir(f)]
# flist contains all files in this directory. If no file filters are specified 
# then all of these files are included after asking. If FILES = '*' then they
# are included without asking.
if len(fsel) == 0 : 
    if getans('Do you want to copy all files here into %s?[y/n] '%vdir).upper() \
    != 'Y' : exit()
    fsel = ['*']

src = list()
fex = list() # File exclusion list
# Go through the file filter list, recording all files in this directory that 
# pass each filter. If a filter is "*" record all files and stop processing 
# the filter list, as any other filters are superfluous. 
for ffil in fsel : 
    if len(ffil) > 2 and ffil[0:2] == '-[' and ffil[-1:] == ']' :
        fex = ffil[2:-1].split(',')
        continue
    idx = 0
    if ffil == '*' : # All files
        for f in flist :
            if f in fex : continue
            if accept(f) :
                src.append(f)
        break # Any other filters are superfluous
    elif ffil[0] == '.' : # '.ext' or '.' 
        idx = - len(ffil) # e.g. .=-1, .py = -3
# Copy fully named file or all that pass .ext filter.
    for f in flist :
        if f in fex : continue
        if f[idx::] == ffil or idx == -1 and not '.' in f :
            src.append(f)
            if idx == 0 : # filter is a complete file name
                break # No need to search for another.
if len(src) == 0 :
    print("No files pass your filters")
    exit()

if verinc :
    mrdir = repdir + mrver + '/'
    for f in src :
        f2 = '%s%s'%(mrdir,f)
        if not os.path.exists(f2) or not filecmp.cmp(f,f2) : break
    else :
        print('All files are identical to those in %s.'%mrver, end = ' ')
        if getans('Do you want to make %s anyway? '%vname).upper() != 'Y' : exit()

if not os.path.exists(vdir) : os.mkdir(vdir)
for f in src :
    shutil.copy2(f, vdir)
print(', '.join(src) + ' copied into ' + vdir)
